import { useState, useEffect } from 'react';
import './App.css';
import Navigation from './components/Navigation';
import Hero from './sections/Hero';
import AIDesignStudio from './sections/AIDesignStudio';
import DesignerMarketplace from './sections/DesignerMarketplace';
import HowItWorks from './sections/HowItWorks';
import CommunicationHub from './sections/CommunicationHub';
import VerificationCenter from './sections/VerificationCenter';
import Pricing from './sections/Pricing';
import Testimonials from './sections/Testimonials';
import Footer from './sections/Footer';
import AuthModal from './components/AuthModal';
import DesignerProfile from './sections/DesignerProfile';
import OrderTracking from './sections/OrderTracking';

export type UserRole = 'customer' | 'designer' | 'dealer' | 'manufacturer' | null;
export type ViewState = 'home' | 'designer-profile' | 'order-tracking' | 'messages';

function App() {
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentView, setCurrentView] = useState<ViewState>('home');
  const [selectedDesigner, setSelectedDesigner] = useState<string | null>(null);

  useEffect(() => {
    // Check for stored auth state
    const storedAuth = localStorage.getItem('diamondai_auth');
    if (storedAuth) {
      const auth = JSON.parse(storedAuth);
      setIsLoggedIn(auth.isLoggedIn);
      setUserRole(auth.role);
    }
  }, []);

  const handleLogin = (role: UserRole) => {
    setUserRole(role);
    setIsLoggedIn(true);
    setIsAuthOpen(false);
    localStorage.setItem('diamondai_auth', JSON.stringify({ isLoggedIn: true, role }));
  };

  const handleLogout = () => {
    setUserRole(null);
    setIsLoggedIn(false);
    localStorage.removeItem('diamondai_auth');
    setCurrentView('home');
  };

  const openAuth = (mode: 'login' | 'signup') => {
    setAuthMode(mode);
    setIsAuthOpen(true);
  };

  const navigateToDesigner = (designerId: string) => {
    setSelectedDesigner(designerId);
    setCurrentView('designer-profile');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateToOrderTracking = () => {
    setCurrentView('order-tracking');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateHome = () => {
    setCurrentView('home');
    setSelectedDesigner(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#050A14] via-[#0a1628] to-[#050A14]">
      <Navigation 
        isLoggedIn={isLoggedIn} 
        userRole={userRole} 
        onOpenAuth={openAuth}
        onLogout={handleLogout}
        onNavigateHome={navigateHome}
        onNavigateOrders={navigateToOrderTracking}
        currentView={currentView}
      />
      
      {currentView === 'home' && (
        <main>
          <Hero onOpenAuth={openAuth} />
          <AIDesignStudio />
          <DesignerMarketplace onDesignerClick={navigateToDesigner} />
          <HowItWorks />
          <CommunicationHub isLoggedIn={isLoggedIn} onOpenAuth={openAuth} />
          <VerificationCenter />
          <Pricing onOpenAuth={openAuth} />
          <Testimonials />
        </main>
      )}

      {currentView === 'designer-profile' && selectedDesigner && (
        <DesignerProfile 
          designerId={selectedDesigner} 
          onBack={navigateHome}
          onOpenAuth={openAuth}
          isLoggedIn={isLoggedIn}
        />
      )}

      {currentView === 'order-tracking' && (
        <OrderTracking onBack={navigateHome} />
      )}

      <Footer />
      
      <AuthModal 
        isOpen={isAuthOpen} 
        onClose={() => setIsAuthOpen(false)} 
        mode={authMode}
        onLogin={handleLogin}
      />
    </div>
  );
}

export default App;
