import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { 
  Sparkles, 
  Wand2, 
  RefreshCw, 
  Heart, 
  Share2, 
  Download,
  Gem,
  Circle,
  Square,
  Watch,
  Crown,
  ChevronRight,
  Check
} from 'lucide-react';

interface GeneratedDesign {
  id: string;
  image: string;
  title: string;
  description: string;
  price: string;
  carat: string;
  cut: string;
  color: string;
  liked: boolean;
}

export default function AIDesignStudio() {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedDesigns, setGeneratedDesigns] = useState<GeneratedDesign[]>([]);
  const [selectedType, setSelectedType] = useState('ring');
  const [budget, setBudget] = useState([5000]);
  const [carat, setCarat] = useState([1.0]);
  const [selectedCut, setSelectedCut] = useState('round');
  const [selectedColor, setSelectedColor] = useState('D');
  const [showResults, setShowResults] = useState(false);

  const jewelryTypes = [
    { id: 'ring', label: 'Ring', icon: Circle },
    { id: 'necklace', label: 'Necklace', icon: Square },
    { id: 'earrings', label: 'Earrings', icon: Gem },
    { id: 'bracelet', label: 'Bracelet', icon: Watch },
    { id: 'pendant', label: 'Pendant', icon: Crown },
  ];

  const diamondCuts = ['round', 'princess', 'cushion', 'oval', 'pear', 'emerald', 'marquise', 'asscher'];
  const diamondColors = ['D', 'E', 'F', 'G', 'H', 'I', 'J'];

  const sampleDesigns: GeneratedDesign[] = [
    {
      id: '1',
      image: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=400&h=400&fit=crop',
      title: 'Eternal Radiance',
      description: 'A stunning solitaire engagement ring with a brilliant round diamond',
      price: '$8,500',
      carat: '1.5',
      cut: 'Round Brilliant',
      color: 'D',
      liked: false,
    },
    {
      id: '2',
      image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=400&h=400&fit=crop',
      title: 'Royal Halo',
      description: 'Elegant halo setting with pavé diamonds surrounding the center stone',
      price: '$12,300',
      carat: '2.0',
      cut: 'Princess',
      color: 'E',
      liked: false,
    },
    {
      id: '3',
      image: 'https://images.unsplash.com/photo-1603561591411-07134e71a2a9?w=400&h=400&fit=crop',
      title: 'Vintage Charm',
      description: 'Art deco inspired design with intricate milgrain details',
      price: '$6,800',
      carat: '1.2',
      cut: 'Cushion',
      color: 'F',
      liked: false,
    },
    {
      id: '4',
      image: 'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=400&h=400&fit=crop',
      title: 'Modern Minimalist',
      description: 'Clean lines and contemporary bezel setting for the modern bride',
      price: '$5,200',
      carat: '1.0',
      cut: 'Oval',
      color: 'G',
      liked: false,
    },
  ];

  const handleGenerate = async () => {
    setIsGenerating(true);
    // Simulate AI generation
    await new Promise(resolve => setTimeout(resolve, 3000));
    setGeneratedDesigns(sampleDesigns);
    setShowResults(true);
    setIsGenerating(false);
  };

  const toggleLike = (id: string) => {
    setGeneratedDesigns(designs =>
      designs.map(d => d.id === id ? { ...d, liked: !d.liked } : d)
    );
  };

  const scrollToDesigners = () => {
    document.getElementById('designers')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="ai-studio" className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#00FFFF]/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-[#D4AF37]/5 rounded-full blur-[120px]" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-[#00FFFF]/30 mb-6">
            <Wand2 className="w-4 h-4 text-[#00FFFF]" />
            <span className="text-sm text-slate-300">AI Design Studio</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Design Your <span className="text-gradient-gold">Dream Jewelry</span>
          </h2>
          <p className="text-lg text-slate-400 max-w-2xl mx-auto">
            Describe your vision, and our AI will generate unique designs tailored to your preferences. 
            Choose from multiple options and connect with designers to bring them to life.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left Panel - Controls */}
          <div className="lg:col-span-1 space-y-6">
            {/* Jewelry Type */}
            <div className="glass-card rounded-xl p-6">
              <Label className="text-white mb-4 block">Jewelry Type</Label>
              <div className="grid grid-cols-2 gap-3">
                {jewelryTypes.map((type) => (
                  <button
                    key={type.id}
                    onClick={() => setSelectedType(type.id)}
                    className={`flex flex-col items-center gap-2 p-4 rounded-lg border transition-all duration-300 ${
                      selectedType === type.id
                        ? 'border-[#D4AF37] bg-[#D4AF37]/10'
                        : 'border-[#D4AF37]/20 hover:border-[#D4AF37]/40'
                    }`}
                  >
                    <type.icon className={`w-6 h-6 ${selectedType === type.id ? 'text-[#D4AF37]' : 'text-slate-400'}`} />
                    <span className={`text-sm ${selectedType === type.id ? 'text-white' : 'text-slate-400'}`}>
                      {type.label}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Budget Slider */}
            <div className="glass-card rounded-xl p-6">
              <div className="flex justify-between mb-4">
                <Label className="text-white">Budget</Label>
                <span className="text-[#D4AF37] font-semibold">${budget[0].toLocaleString()}</span>
              </div>
              <Slider
                value={budget}
                onValueChange={setBudget}
                min={1000}
                max={100000}
                step={1000}
                className="w-full"
              />
              <div className="flex justify-between mt-2 text-xs text-slate-500">
                <span>$1,000</span>
                <span>$100,000+</span>
              </div>
            </div>

            {/* Carat Slider */}
            <div className="glass-card rounded-xl p-6">
              <div className="flex justify-between mb-4">
                <Label className="text-white">Carat Weight</Label>
                <span className="text-[#D4AF37] font-semibold">{carat[0]} ct</span>
              </div>
              <Slider
                value={carat}
                onValueChange={setCarat}
                min={0.5}
                max={5}
                step={0.1}
                className="w-full"
              />
              <div className="flex justify-between mt-2 text-xs text-slate-500">
                <span>0.5 ct</span>
                <span>5.0 ct</span>
              </div>
            </div>

            {/* Diamond Cut */}
            <div className="glass-card rounded-xl p-6">
              <Label className="text-white mb-4 block">Diamond Cut</Label>
              <div className="flex flex-wrap gap-2">
                {diamondCuts.map((cut) => (
                  <button
                    key={cut}
                    onClick={() => setSelectedCut(cut)}
                    className={`px-3 py-1.5 rounded-full text-sm capitalize transition-all duration-300 ${
                      selectedCut === cut
                        ? 'bg-[#D4AF37] text-black font-medium'
                        : 'bg-[#0F172A] text-slate-400 border border-[#D4AF37]/20 hover:border-[#D4AF37]/40'
                    }`}
                  >
                    {cut}
                  </button>
                ))}
              </div>
            </div>

            {/* Diamond Color */}
            <div className="glass-card rounded-xl p-6">
              <Label className="text-white mb-4 block">Color Grade</Label>
              <div className="flex flex-wrap gap-2">
                {diamondColors.map((color) => (
                  <button
                    key={color}
                    onClick={() => setSelectedColor(color)}
                    className={`w-10 h-10 rounded-lg text-sm font-medium transition-all duration-300 ${
                      selectedColor === color
                        ? 'bg-[#D4AF37] text-black'
                        : 'bg-[#0F172A] text-slate-400 border border-[#D4AF37]/20 hover:border-[#D4AF37]/40'
                    }`}
                  >
                    {color}
                  </button>
                ))}
              </div>
              <p className="text-xs text-slate-500 mt-2">D = Colorless, J = Near Colorless</p>
            </div>
          </div>

          {/* Right Panel - Prompt & Results */}
          <div className="lg:col-span-2 space-y-6">
            {/* Prompt Input */}
            <div className="glass-card rounded-xl p-6">
              <Label className="text-white mb-4 block">Describe Your Vision</Label>
              <Textarea
                placeholder="E.g., A vintage-inspired engagement ring with a halo setting, rose gold band, and intricate filigree details..."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="bg-[#0F172A] border-[#D4AF37]/30 text-white placeholder:text-slate-500 min-h-[120px] focus:border-[#D4AF37] resize-none"
              />
              <div className="flex justify-between items-center mt-4">
                <p className="text-sm text-slate-500">
                  Be specific about style, metal, and setting preferences
                </p>
                <Button
                  onClick={handleGenerate}
                  disabled={isGenerating || !prompt.trim()}
                  className="bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-black font-medium hover:shadow-lg hover:shadow-[#D4AF37]/30 disabled:opacity-50"
                >
                  {isGenerating ? (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Generate Designs
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Generated Designs */}
            {showResults && (
              <div className="space-y-6 animate-fadeInUp">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-semibold text-white">AI-Generated Designs</h3>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleGenerate}
                    className="border-[#D4AF37]/30 text-[#D4AF37]"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Regenerate
                  </Button>
                </div>

                <div className="grid sm:grid-cols-2 gap-6">
                  {generatedDesigns.map((design, index) => (
                    <div
                      key={design.id}
                      className="glass-card rounded-xl overflow-hidden group hover:border-[#D4AF37]/40 transition-all duration-300"
                      style={{ animationDelay: `${index * 0.1}s` }}
                    >
                      {/* Image */}
                      <div className="relative aspect-square overflow-hidden">
                        <img
                          src={design.image}
                          alt={design.title}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                        
                        {/* Actions */}
                        <div className="absolute top-4 right-4 flex gap-2">
                          <button
                            onClick={() => toggleLike(design.id)}
                            className="w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-[#D4AF37]/20 transition-colors"
                          >
                            <Heart className={`w-5 h-5 ${design.liked ? 'fill-red-500 text-red-500' : 'text-white'}`} />
                          </button>
                          <button className="w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-[#D4AF37]/20 transition-colors">
                            <Share2 className="w-5 h-5 text-white" />
                          </button>
                        </div>

                        {/* Price Tag */}
                        <div className="absolute bottom-4 left-4">
                          <span className="px-3 py-1 rounded-full bg-[#D4AF37] text-black text-sm font-semibold">
                            {design.price}
                          </span>
                        </div>
                      </div>

                      {/* Content */}
                      <div className="p-5">
                        <h4 className="text-lg font-semibold text-white mb-1">{design.title}</h4>
                        <p className="text-sm text-slate-400 mb-4">{design.description}</p>
                        
                        {/* Specs */}
                        <div className="flex flex-wrap gap-2 mb-4">
                          <span className="px-2 py-1 rounded-md bg-[#0F172A] text-xs text-slate-400">
                            {design.carat} ct
                          </span>
                          <span className="px-2 py-1 rounded-md bg-[#0F172A] text-xs text-slate-400">
                            {design.cut}
                          </span>
                          <span className="px-2 py-1 rounded-md bg-[#0F172A] text-xs text-slate-400">
                            Color {design.color}
                          </span>
                        </div>

                        {/* Actions */}
                        <div className="flex gap-3">
                          <Button
                            variant="outline"
                            size="sm"
                            className="flex-1 border-[#D4AF37]/30 text-[#D4AF37]"
                          >
                            <Download className="w-4 h-4 mr-2" />
                            Save
                          </Button>
                          <Button
                            size="sm"
                            onClick={scrollToDesigners}
                            className="flex-1 bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-black font-medium"
                          >
                            Find Designers
                            <ChevronRight className="w-4 h-4 ml-1" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* CTA */}
                <div className="glass-card rounded-xl p-6 text-center">
                  <p className="text-slate-400 mb-4">
                    Want to customize one of these designs further?
                  </p>
                  <Button
                    onClick={scrollToDesigners}
                    className="bg-gradient-to-r from-[#00FFFF] to-[#00CCCC] text-black font-medium hover:shadow-lg hover:shadow-[#00FFFF]/30"
                  >
                    Connect with a Designer
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </div>
            )}

            {/* Empty State */}
            {!showResults && !isGenerating && (
              <div className="glass-card rounded-xl p-12 text-center">
                <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-[#D4AF37]/20 to-[#00FFFF]/20 flex items-center justify-center">
                  <Wand2 className="w-10 h-10 text-[#D4AF37]" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Ready to Create?</h3>
                <p className="text-slate-400 max-w-md mx-auto mb-6">
                  Describe your dream jewelry piece, adjust the parameters, and let our AI generate 
                  unique designs tailored to your preferences.
                </p>
                <div className="flex flex-wrap justify-center gap-4 text-sm text-slate-500">
                  <span className="flex items-center gap-1">
                    <Check className="w-4 h-4 text-[#D4AF37]" />
                    4 unique designs
                  </span>
                  <span className="flex items-center gap-1">
                    <Check className="w-4 h-4 text-[#D4AF37]" />
                    Instant generation
                  </span>
                  <span className="flex items-center gap-1">
                    <Check className="w-4 h-4 text-[#D4AF37]" />
                    Free to use
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
