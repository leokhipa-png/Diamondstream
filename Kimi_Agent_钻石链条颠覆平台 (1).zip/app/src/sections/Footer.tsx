import { 
  Diamond, 
  Mail, 
  Phone, 
  MapPin, 
  Instagram, 
  Twitter, 
  Facebook, 
  Linkedin,
  ArrowRight,
  Heart
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export default function Footer() {
  const footerLinks = {
    platform: [
      { label: 'AI Design Studio', href: '#ai-studio' },
      { label: 'Designer Marketplace', href: '#designers' },
      { label: 'How It Works', href: '#how-it-works' },
      { label: 'Pricing', href: '#pricing' },
    ],
    company: [
      { label: 'About Us', href: '#' },
      { label: 'Careers', href: '#' },
      { label: 'Press', href: '#' },
      { label: 'Blog', href: '#' },
    ],
    support: [
      { label: 'Help Center', href: '#' },
      { label: 'Contact Us', href: '#' },
      { label: 'Privacy Policy', href: '#' },
      { label: 'Terms of Service', href: '#' },
    ],
    partners: [
      { label: 'For Designers', href: '#' },
      { label: 'For Dealers', href: '#' },
      { label: 'For Manufacturers', href: '#' },
      { label: 'Partner Portal', href: '#' },
    ],
  };

  return (
    <footer className="relative pt-24 pb-8 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#050A14] via-[#0a1628] to-transparent" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Newsletter Section */}
        <div className="glass-card rounded-2xl p-8 lg:p-12 mb-16">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl lg:text-3xl font-bold text-white mb-4">
                Stay Updated with <span className="text-gradient-gold">DIAMOND.ai</span>
              </h3>
              <p className="text-slate-400">
                Subscribe to our newsletter for the latest designs, exclusive offers, 
                and jewelry industry insights.
              </p>
            </div>
            <div className="flex gap-3">
              <div className="relative flex-1">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <Input
                  type="email"
                  placeholder="Enter your email"
                  className="pl-12 bg-[#0F172A] border-[#D4AF37]/30 text-white placeholder:text-slate-500 focus:border-[#D4AF37]"
                />
              </div>
              <Button className="bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-black font-medium hover:shadow-lg hover:shadow-[#D4AF37]/30">
                Subscribe
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        </div>

        {/* Main Footer Content */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 mb-12">
          {/* Brand Column */}
          <div className="col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <Diamond className="w-8 h-8 text-[#D4AF37]" />
              <span className="text-xl font-bold text-gradient-gold font-['Playfair_Display']">
                DIAMOND.ai
              </span>
            </div>
            <p className="text-slate-400 mb-6 max-w-sm">
              The future of luxury jewelry. AI-powered design, verified professionals, 
              and transparent supply chains.
            </p>
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-slate-400">
                <Mail className="w-4 h-4 text-[#D4AF37]" />
                <span className="text-sm">hello@diamond.ai</span>
              </div>
              <div className="flex items-center gap-3 text-slate-400">
                <Phone className="w-4 h-4 text-[#D4AF37]" />
                <span className="text-sm">+1 (888) 555-0123</span>
              </div>
              <div className="flex items-center gap-3 text-slate-400">
                <MapPin className="w-4 h-4 text-[#D4AF37]" />
                <span className="text-sm">New York, NY 10001</span>
              </div>
            </div>
          </div>

          {/* Links Columns */}
          <div>
            <h4 className="font-semibold text-white mb-4">Platform</h4>
            <ul className="space-y-3">
              {footerLinks.platform.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm text-slate-400 hover:text-[#D4AF37] transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-4">Company</h4>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm text-slate-400 hover:text-[#D4AF37] transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-4">Support</h4>
            <ul className="space-y-3">
              {footerLinks.support.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm text-slate-400 hover:text-[#D4AF37] transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-4">Partners</h4>
            <ul className="space-y-3">
              {footerLinks.partners.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm text-slate-400 hover:text-[#D4AF37] transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Social Links & Copyright */}
        <div className="pt-8 border-t border-[#D4AF37]/10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            {/* Social Links */}
            <div className="flex items-center gap-4">
              {[
                { icon: Instagram, href: '#' },
                { icon: Twitter, href: '#' },
                { icon: Facebook, href: '#' },
                { icon: Linkedin, href: '#' },
              ].map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  className="w-10 h-10 rounded-full glass flex items-center justify-center text-slate-400 hover:text-[#D4AF37] hover:border-[#D4AF37]/50 transition-all"
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>

            {/* Copyright */}
            <div className="flex items-center gap-1 text-sm text-slate-500">
              <span>Made with</span>
              <Heart className="w-4 h-4 text-red-500 fill-red-500" />
              <span>by DIAMOND.ai Team</span>
            </div>

            {/* Legal */}
            <div className="flex items-center gap-6 text-sm text-slate-500">
              <a href="#" className="hover:text-[#D4AF37] transition-colors">Privacy</a>
              <a href="#" className="hover:text-[#D4AF37] transition-colors">Terms</a>
              <a href="#" className="hover:text-[#D4AF37] transition-colors">Cookies</a>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="mt-8 text-center">
            <p className="text-xs text-slate-600">
              © {new Date().getFullYear()} DIAMOND.ai. All rights reserved. 
              All diamonds are ethically sourced and conflict-free.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
