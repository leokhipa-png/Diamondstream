import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { 
  Check, 
  Sparkles, 
  Gem, 
  Crown, 
  Zap,
  ArrowRight,
  HelpCircle
} from 'lucide-react';

interface PricingPlan {
  id: string;
  name: string;
  icon: React.ElementType;
  description: string;
  monthlyPrice: number;
  yearlyPrice: number;
  features: string[];
  highlighted?: boolean;
  cta: string;
  color: string;
}

interface PricingProps {
  onOpenAuth: (mode: 'login' | 'signup') => void;
}

export default function Pricing({ onOpenAuth }: PricingProps) {
  const [isYearly, setIsYearly] = useState(false);

  const customerPlans: PricingPlan[] = [
    {
      id: 'free',
      name: 'Explorer',
      icon: Sparkles,
      description: 'Perfect for browsing and AI design generation',
      monthlyPrice: 0,
      yearlyPrice: 0,
      features: [
        'Unlimited AI design generation',
        'Browse designer portfolios',
        'Save up to 10 designs',
        'Basic search filters',
        'Email support',
      ],
      cta: 'Get Started Free',
      color: '#94A3B8',
    },
    {
      id: 'premium',
      name: 'Collector',
      icon: Gem,
      description: 'For serious buyers and collectors',
      monthlyPrice: 29,
      yearlyPrice: 290,
      features: [
        'Everything in Explorer',
        'Unlimited design saves',
        'Priority designer matching',
        'Video consultations',
        'Price negotiation tools',
        'Dedicated support',
        'Early access to new features',
      ],
      highlighted: true,
      cta: 'Start 14-Day Trial',
      color: '#D4AF37',
    },
    {
      id: 'vip',
      name: 'Connoisseur',
      icon: Crown,
      description: 'Ultimate luxury experience',
      monthlyPrice: 99,
      yearlyPrice: 990,
      features: [
        'Everything in Collector',
        'Personal jewelry advisor',
        'VIP designer access',
        'Private showings',
        'White-glove service',
        'Custom commission priority',
        'Invitation-only events',
      ],
      cta: 'Apply for Access',
      color: '#00FFFF',
    },
  ];

  const professionalPlans: PricingPlan[] = [
    {
      id: 'designer-basic',
      name: 'Designer Starter',
      icon: Zap,
      description: 'For independent jewelry designers',
      monthlyPrice: 49,
      yearlyPrice: 490,
      features: [
        'List up to 10 designs',
        'Basic profile & portfolio',
        'Customer messaging',
        'Standard commission (15%)',
        'Monthly payouts',
      ],
      cta: 'Join as Designer',
      color: '#10B981',
    },
    {
      id: 'designer-pro',
      name: 'Designer Pro',
      icon: Gem,
      description: 'For established design studios',
      monthlyPrice: 149,
      yearlyPrice: 1490,
      features: [
        'Unlimited design listings',
        'Enhanced profile & analytics',
        'Video consultation tools',
        'Reduced commission (10%)',
        'Weekly payouts',
        'Priority search placement',
        'Marketing support',
      ],
      highlighted: true,
      cta: 'Upgrade to Pro',
      color: '#D4AF37',
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      icon: Crown,
      description: 'For luxury brands & manufacturers',
      monthlyPrice: 499,
      yearlyPrice: 4990,
      features: [
        'Everything in Pro',
        'White-label options',
        'API access',
        'Lowest commission (5%)',
        'Daily payouts',
        'Dedicated account manager',
        'Custom integrations',
      ],
      cta: 'Contact Sales',
      color: '#00FFFF',
    },
  ];

  const [activeTab, setActiveTab] = useState<'customers' | 'professionals'>('customers');
  const plans = activeTab === 'customers' ? customerPlans : professionalPlans;

  return (
    <section id="pricing" className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-[#D4AF37]/5 rounded-full blur-[150px]" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-[#D4AF37]/30 mb-6">
            <Sparkles className="w-4 h-4 text-[#D4AF37]" />
            <span className="text-sm text-slate-300">Pricing</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Simple, <span className="text-gradient-gold">Transparent</span> Pricing
          </h2>
          <p className="text-lg text-slate-400 max-w-2xl mx-auto">
            Choose the plan that fits your needs. No hidden fees, no surprises.
          </p>
        </div>

        {/* Tabs */}
        <div className="flex justify-center mb-8">
          <div className="glass rounded-full p-1 flex">
            <button
              onClick={() => setActiveTab('customers')}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                activeTab === 'customers'
                  ? 'bg-[#D4AF37] text-black'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              For Customers
            </button>
            <button
              onClick={() => setActiveTab('professionals')}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                activeTab === 'professionals'
                  ? 'bg-[#D4AF37] text-black'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              For Professionals
            </button>
          </div>
        </div>

        {/* Billing Toggle */}
        <div className="flex items-center justify-center gap-4 mb-12">
          <span className={`text-sm ${!isYearly ? 'text-white' : 'text-slate-400'}`}>Monthly</span>
          <Switch
            checked={isYearly}
            onCheckedChange={setIsYearly}
          />
          <span className={`text-sm ${isYearly ? 'text-white' : 'text-slate-400'}`}>
            Yearly
            <Badge className="ml-2 bg-green-500/20 text-green-400">Save 20%</Badge>
          </span>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <div
              key={plan.id}
              className={`relative rounded-2xl p-8 transition-all duration-500 ${
                plan.highlighted
                  ? 'glass-card border-[#D4AF37]/50 scale-105 z-10'
                  : 'glass-card hover:border-[#D4AF37]/30'
              }`}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Popular Badge */}
              {plan.highlighted && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <Badge className="bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-black font-medium px-4 py-1">
                    Most Popular
                  </Badge>
                </div>
              )}

              {/* Icon */}
              <div
                className="w-14 h-14 rounded-xl flex items-center justify-center mb-6"
                style={{ background: `${plan.color}20` }}
              >
                <plan.icon className="w-7 h-7" style={{ color: plan.color }} />
              </div>

              {/* Plan Info */}
              <h3 className="text-xl font-bold text-white mb-2">{plan.name}</h3>
              <p className="text-sm text-slate-400 mb-6">{plan.description}</p>

              {/* Price */}
              <div className="mb-6">
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-bold text-white">
                    ${isYearly ? plan.yearlyPrice : plan.monthlyPrice}
                  </span>
                  <span className="text-slate-400">
                    /{isYearly ? 'year' : 'month'}
                  </span>
                </div>
                {isYearly && plan.monthlyPrice > 0 && (
                  <p className="text-sm text-green-400 mt-1">
                    Save ${plan.monthlyPrice * 12 - plan.yearlyPrice}/year
                  </p>
                )}
              </div>

              {/* Features */}
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm text-slate-300">
                    <Check className="w-5 h-5 text-[#D4AF37] flex-shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>

              {/* CTA */}
              <Button
                onClick={() => onOpenAuth('signup')}
                className={`w-full ${
                  plan.highlighted
                    ? 'bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-black font-medium hover:shadow-lg hover:shadow-[#D4AF37]/30'
                    : 'border border-[#D4AF37]/30 text-[#D4AF37] hover:bg-[#D4AF37]/10'
                }`}
                variant={plan.highlighted ? 'default' : 'outline'}
              >
                {plan.cta}
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          ))}
        </div>

        {/* Additional Info */}
        <div className="mt-16 glass-card rounded-2xl p-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[#D4AF37]/20 to-[#00FFFF]/20 flex items-center justify-center flex-shrink-0">
                <HelpCircle className="w-6 h-6 text-[#D4AF37]" />
              </div>
              <div>
                <h4 className="font-semibold text-white mb-1">Questions?</h4>
                <p className="text-sm text-slate-400">
                  Our team is here to help. Contact us for personalized guidance.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[#D4AF37]/20 to-[#00FFFF]/20 flex items-center justify-center flex-shrink-0">
                <Check className="w-6 h-6 text-[#D4AF37]" />
              </div>
              <div>
                <h4 className="font-semibold text-white mb-1">Cancel Anytime</h4>
                <p className="text-sm text-slate-400">
                  No long-term contracts. Cancel your subscription at any time.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[#D4AF37]/20 to-[#00FFFF]/20 flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-6 h-6 text-[#D4AF37]" />
              </div>
              <div>
                <h4 className="font-semibold text-white mb-1">14-Day Free Trial</h4>
                <p className="text-sm text-slate-400">
                  Try any plan risk-free for 14 days. No credit card required.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Money Back Guarantee */}
        <div className="mt-8 text-center">
          <p className="text-slate-400">
            <span className="text-[#D4AF37]">30-Day Money-Back Guarantee</span> on all paid plans
          </p>
        </div>
      </div>
    </section>
  );
}
