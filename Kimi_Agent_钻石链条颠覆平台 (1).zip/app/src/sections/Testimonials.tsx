import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Star, 
  Quote, 
  ChevronLeft, 
  ChevronRight,
  Heart,
  Sparkles,
  Verified
} from 'lucide-react';

interface Testimonial {
  id: string;
  name: string;
  avatar: string;
  role: string;
  location: string;
  rating: number;
  text: string;
  designImage: string;
  designName: string;
  designerName: string;
  verified: boolean;
}

export default function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const testimonials: Testimonial[] = [
    {
      id: '1',
      name: 'Sarah Mitchell',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      role: 'Bride',
      location: 'New York, USA',
      rating: 5,
      text: 'DIAMOND.ai made my dream engagement ring a reality. The AI generated designs that perfectly matched my vision, and Elena, my designer, brought it to life beautifully. The entire process was transparent, and I could track every step. Absolutely magical experience!',
      designImage: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=400&h=400&fit=crop',
      designName: 'Eternal Radiance',
      designerName: 'Elena Rodriguez',
      verified: true,
    },
    {
      id: '2',
      name: 'Michael Chen',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
      role: 'Collector',
      location: 'Singapore',
      rating: 5,
      text: 'As a serious jewelry collector, I was skeptical at first. But the verification process and quality of designers on this platform exceeded my expectations. The direct communication with designers and transparent pricing is a game-changer.',
      designImage: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=400&h=400&fit=crop',
      designName: 'Royal Halo Pendant',
      designerName: 'Marcus Chen',
      verified: true,
    },
    {
      id: '3',
      name: 'Isabella Romano',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
      role: 'Fashion Influencer',
      location: 'Milan, Italy',
      rating: 5,
      text: 'The AI design studio is incredible! I described my style preferences and got stunning designs instantly. Working with Sofia was a dream - she understood exactly what I wanted. My followers are obsessed with my custom pieces!',
      designImage: 'https://images.unsplash.com/photo-1603561591411-07134e71a2a9?w=400&h=400&fit=crop',
      designName: 'Vintage Charm Bracelet',
      designerName: 'Sofia Andersson',
      verified: true,
    },
    {
      id: '4',
      name: 'David Thompson',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop',
      role: 'Anniversary Gift',
      location: 'London, UK',
      rating: 5,
      text: 'For our 25th anniversary, I wanted something truly special. DIAMOND.ai connected me with James Wellington, who created a breathtaking necklace for my wife. The certificate verification gave me complete confidence in the diamonds.',
      designImage: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=400&h=400&fit=crop',
      designName: 'Silver Jubilee Necklace',
      designerName: 'James Wellington',
      verified: true,
    },
  ];

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const currentTestimonial = testimonials[currentIndex];

  return (
    <section className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-[#D4AF37]/5 rounded-full blur-[100px]" />
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#00FFFF]/5 rounded-full blur-[100px]" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-[#D4AF37]/30 mb-6">
            <Heart className="w-4 h-4 text-[#D4AF37]" />
            <span className="text-sm text-slate-300">Testimonials</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Loved by <span className="text-gradient-gold">Thousands</span>
          </h2>
          <p className="text-lg text-slate-400 max-w-2xl mx-auto">
            See what our customers and designers say about their experience with DIAMOND.ai
          </p>
        </div>

        {/* Featured Testimonial */}
        <div className="glass-card rounded-2xl overflow-hidden">
          <div className="grid lg:grid-cols-2">
            {/* Design Image */}
            <div className="relative h-64 lg:h-auto">
              <img
                src={currentTestimonial.designImage}
                alt={currentTestimonial.designName}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[#0F172A]/90 lg:bg-gradient-to-l" />
              
              {/* Design Info Overlay */}
              <div className="absolute bottom-6 left-6 right-6">
                <div className="glass rounded-xl p-4">
                  <p className="text-sm text-slate-400 mb-1">Custom Design</p>
                  <h4 className="text-lg font-semibold text-white">{currentTestimonial.designName}</h4>
                  <p className="text-sm text-[#D4AF37]">by {currentTestimonial.designerName}</p>
                </div>
              </div>
            </div>

            {/* Testimonial Content */}
            <div className="p-8 lg:p-12 flex flex-col justify-center">
              {/* Quote Icon */}
              <Quote className="w-12 h-12 text-[#D4AF37]/30 mb-6" />

              {/* Rating */}
              <div className="flex items-center gap-1 mb-4">
                {[...Array(currentTestimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-[#D4AF37] fill-[#D4AF37]" />
                ))}
              </div>

              {/* Testimonial Text */}
              <p className="text-lg text-slate-300 leading-relaxed mb-8">
                &ldquo;{currentTestimonial.text}&rdquo;
              </p>

              {/* Author Info */}
              <div className="flex items-center gap-4">
                <img
                  src={currentTestimonial.avatar}
                  alt={currentTestimonial.name}
                  className="w-14 h-14 rounded-full object-cover border-2 border-[#D4AF37]/30"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-semibold text-white">{currentTestimonial.name}</h4>
                    {currentTestimonial.verified && (
                      <Verified className="w-4 h-4 text-[#00FFFF]" />
                    )}
                  </div>
                  <p className="text-sm text-slate-400">{currentTestimonial.role}</p>
                  <p className="text-sm text-slate-500">{currentTestimonial.location}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-center gap-4 mt-8">
          <Button
            variant="outline"
            size="icon"
            onClick={prevTestimonial}
            className="border-[#D4AF37]/30 text-[#D4AF37] hover:bg-[#D4AF37]/10"
          >
            <ChevronLeft className="w-5 h-5" />
          </Button>
          
          {/* Dots */}
          <div className="flex items-center gap-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  index === currentIndex
                    ? 'w-8 bg-[#D4AF37]'
                    : 'bg-slate-600 hover:bg-slate-500'
                }`}
              />
            ))}
          </div>

          <Button
            variant="outline"
            size="icon"
            onClick={nextTestimonial}
            className="border-[#D4AF37]/30 text-[#D4AF37] hover:bg-[#D4AF37]/10"
          >
            <ChevronRight className="w-5 h-5" />
          </Button>
        </div>

        {/* Stats */}
        <div className="mt-16 grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { value: '4.9', label: 'Average Rating', icon: Star },
            { value: '10,000+', label: 'Happy Customers', icon: Heart },
            { value: '500+', label: 'Verified Designers', icon: Verified },
            { value: '50,000+', label: 'Designs Created', icon: Sparkles },
          ].map((stat, index) => (
            <div
              key={stat.label}
              className="text-center p-6 rounded-xl glass-card"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="w-12 h-12 mx-auto mb-4 rounded-full bg-gradient-to-br from-[#D4AF37]/20 to-[#00FFFF]/20 flex items-center justify-center">
                <stat.icon className="w-6 h-6 text-[#D4AF37]" />
              </div>
              <p className="text-3xl font-bold text-gradient-gold mb-1">{stat.value}</p>
              <p className="text-sm text-slate-400">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
