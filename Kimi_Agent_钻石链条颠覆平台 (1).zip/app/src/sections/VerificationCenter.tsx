import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Shield, 
  CheckCircle, 
  FileCheck, 
  Award, 
  Globe,
  Lock,
  Eye,
  Upload,
  Building2,
  UserCheck,
  Gem,
  Search,
  FileText
} from 'lucide-react';

interface VerificationTier {
  id: string;
  name: string;
  icon: React.ElementType;
  description: string;
  requirements: string[];
  benefits: string[];
  color: string;
}

export default function VerificationCenter() {
  const [activeTab, setActiveTab] = useState<'designers' | 'dealers' | 'manufacturers'>('designers');

  const verificationTiers: Record<string, VerificationTier[]> = {
    designers: [
      {
        id: 'basic',
        name: 'Verified Designer',
        icon: UserCheck,
        description: 'Entry-level verification for independent designers',
        requirements: [
          'Government-issued ID',
          'Proof of address',
          'Portfolio of previous work',
          'Professional references (2)',
        ],
        benefits: [
          'List up to 10 designs',
          'Basic analytics dashboard',
          'Customer messaging',
          'Standard support',
        ],
        color: '#10B981',
      },
      {
        id: 'premium',
        name: 'Premium Designer',
        icon: Award,
        description: 'Enhanced verification for established professionals',
        requirements: [
          'All Basic requirements',
          'Business registration certificate',
          '5+ years experience proof',
          'Insurance certificate',
          'Client testimonials (10+)',
        ],
        benefits: [
          'Unlimited design listings',
          'Advanced analytics',
          'Priority placement in search',
          'Video consultation tools',
          'Dedicated support',
        ],
        color: '#D4AF37',
      },
      {
        id: 'master',
        name: 'Master Craftsman',
        icon: Gem,
        description: 'Elite tier for renowned jewelry artists',
        requirements: [
          'All Premium requirements',
          'Industry awards or recognition',
          '10+ years experience',
          'Celebrity/client references',
          'In-person interview',
        ],
        benefits: [
          'Featured on homepage',
          'VIP client referrals',
          'Custom commission requests',
          'Marketing support',
          'Early access to features',
        ],
        color: '#00FFFF',
      },
    ],
    dealers: [
      {
        id: 'certified',
        name: 'Certified Dealer',
        icon: FileText,
        description: 'Verified diamond and gemstone suppliers',
        requirements: [
          'Business license',
          'Tax identification',
          'GIA/IGI dealer certificate',
          'Warehouse inspection',
          'Bank reference',
        ],
        benefits: [
          'List inventory',
          'Access to designer network',
          'Secure payment processing',
          'Shipping integration',
        ],
        color: '#10B981',
      },
      {
        id: 'premier',
        name: 'Premier Supplier',
        icon: Globe,
        description: 'Elite suppliers with global reach',
        requirements: [
          'All Certified requirements',
          '5+ years in business',
          '$5M+ annual revenue',
          'International shipping capability',
          'Insurance coverage',
        ],
        benefits: [
          'Priority matching with designers',
          'Bulk order management',
          'Advanced inventory tools',
          'Dedicated account manager',
        ],
        color: '#D4AF37',
      },
    ],
    manufacturers: [
      {
        id: 'approved',
        name: 'Approved Manufacturer',
        icon: Building2,
        description: 'Verified jewelry production facilities',
        requirements: [
          'Factory registration',
          'Safety certifications',
          'Quality control documentation',
          'Environmental compliance',
          'Worker insurance',
        ],
        benefits: [
          'Receive production orders',
          'Milestone payment system',
          'Quality assurance support',
          'Technical documentation',
        ],
        color: '#10B981',
      },
      {
        id: 'excellence',
        name: 'Excellence Certified',
        icon: FileCheck,
        description: 'Premium manufacturers with proven track record',
        requirements: [
          'All Approved requirements',
          'ISO 9001 certification',
          '10+ years operation',
          'Portfolio of 100+ pieces',
          'Designer references',
        ],
        benefits: [
          'Priority order allocation',
          'Premium pricing tier',
          'Direct designer relationships',
          'Marketing collaboration',
        ],
        color: '#D4AF37',
      },
    ],
  };

  const stats = [
    { label: 'Verified Designers', value: '500+', icon: UserCheck },
    { label: 'Certified Dealers', value: '120+', icon: FileText },
    { label: 'Approved Manufacturers', value: '85+', icon: Building2 },
    { label: 'Security Audits', value: 'Monthly', icon: Shield },
  ];

  return (
    <section id="verification" className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 right-0 w-[500px] h-[500px] bg-[#D4AF37]/5 rounded-full blur-[100px]" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-[#00FFFF]/30 mb-6">
            <Shield className="w-4 h-4 text-[#00FFFF]" />
            <span className="text-sm text-slate-300">Trust & Verification</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Our <span className="text-gradient-gold">Verification</span> Process
          </h2>
          <p className="text-lg text-slate-400 max-w-2xl mx-auto">
            Every professional on our platform undergoes rigorous verification. 
            We ensure authenticity, quality, and trust at every step.
          </p>
        </div>

        {/* Stats */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => (
            <div
              key={stat.label}
              className="glass-card rounded-xl p-6 text-center"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-gradient-to-br from-[#D4AF37]/20 to-[#00FFFF]/20 flex items-center justify-center">
                <stat.icon className="w-7 h-7 text-[#D4AF37]" />
              </div>
              <p className="text-3xl font-bold text-gradient-gold mb-1">{stat.value}</p>
              <p className="text-sm text-slate-400">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Verification Tiers */}
        <div className="glass-card rounded-2xl overflow-hidden">
          {/* Tabs */}
          <div className="flex border-b border-[#D4AF37]/10">
            {(['designers', 'dealers', 'manufacturers'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex-1 py-4 px-6 text-sm font-medium capitalize transition-all duration-300 ${
                  activeTab === tab
                    ? 'text-[#D4AF37] border-b-2 border-[#D4AF37] bg-[#D4AF37]/5'
                    : 'text-slate-400 hover:text-white hover:bg-[#D4AF37]/5'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Tier Cards */}
          <div className="p-8">
            <div className={`grid ${activeTab === 'dealers' ? 'md:grid-cols-2' : 'md:grid-cols-3'} gap-6`}>
              {verificationTiers[activeTab].map((tier, index) => (
                <div
                  key={tier.id}
                  className="rounded-xl border border-[#D4AF37]/20 p-6 hover:border-[#D4AF37]/40 transition-all duration-300"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  {/* Header */}
                  <div className="flex items-center gap-3 mb-4">
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center"
                      style={{ background: `${tier.color}20` }}
                    >
                      <tier.icon className="w-6 h-6" style={{ color: tier.color }} />
                    </div>
                    <div>
                      <h3 className="font-semibold text-white">{tier.name}</h3>
                      <Badge
                        className="text-xs"
                        style={{ background: tier.color, color: '#000' }}
                      >
                        {activeTab.slice(0, -1)} tier
                      </Badge>
                    </div>
                  </div>

                  <p className="text-sm text-slate-400 mb-6">{tier.description}</p>

                  {/* Requirements */}
                  <div className="mb-6">
                    <p className="text-xs text-slate-500 uppercase tracking-wider mb-3">Requirements</p>
                    <ul className="space-y-2">
                      {tier.requirements.map((req, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-slate-300">
                          <CheckCircle className="w-4 h-4 mt-0.5 flex-shrink-0" style={{ color: tier.color }} />
                          {req}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Benefits */}
                  <div className="mb-6">
                    <p className="text-xs text-slate-500 uppercase tracking-wider mb-3">Benefits</p>
                    <ul className="space-y-2">
                      {tier.benefits.map((benefit, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-slate-300">
                          <Lock className="w-4 h-4 mt-0.5 flex-shrink-0 text-[#D4AF37]" />
                          {benefit}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <Button
                    variant="outline"
                    className="w-full border-[#D4AF37]/30 text-[#D4AF37] hover:bg-[#D4AF37]/10"
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Apply Now
                  </Button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Certificate Verification */}
        <div className="mt-12 glass-card rounded-2xl p-8">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-[#D4AF37]/30 mb-4">
                <Search className="w-4 h-4 text-[#D4AF37]" />
                <span className="text-sm text-slate-300">Certificate Lookup</span>
              </div>
              <h3 className="text-2xl font-bold text-white mb-4">
                Verify Diamond Certificates
              </h3>
              <p className="text-slate-400 mb-6">
                Enter your GIA, IGI, or HRD certificate number to verify authenticity 
                and access detailed diamond specifications.
              </p>
              <div className="flex gap-3">
                <div className="relative flex-1">
                  <FileText className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Enter certificate number..."
                    className="w-full pl-12 pr-4 py-3 rounded-lg bg-[#0F172A] border border-[#D4AF37]/30 text-white placeholder:text-slate-500 focus:border-[#D4AF37] focus:outline-none"
                  />
                </div>
                <Button className="bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-black font-medium">
                  Verify
                </Button>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <div className="relative">
                <div className="w-48 h-48 rounded-full bg-gradient-to-br from-[#D4AF37]/20 to-[#00FFFF]/20 flex items-center justify-center">
                  <Shield className="w-20 h-20 text-[#D4AF37]" />
                </div>
                <div className="absolute -top-2 -right-2 w-12 h-12 rounded-full bg-green-500 flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Trust Indicators */}
        <div className="mt-12 flex flex-wrap justify-center gap-8">
          {[
            { icon: Lock, label: '256-bit Encryption' },
            { icon: Eye, label: 'Transparent Process' },
            { icon: CheckCircle, label: '100% Verified' },
            { icon: Shield, label: 'Fraud Protection' },
          ].map((item) => (
            <div key={item.label} className="flex items-center gap-2 text-slate-400">
              <item.icon className="w-5 h-5 text-[#D4AF37]" />
              <span className="text-sm">{item.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
