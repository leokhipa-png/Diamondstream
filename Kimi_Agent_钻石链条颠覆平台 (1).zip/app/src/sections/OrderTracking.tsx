import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowLeft, 
  Package, 
  Truck, 
  CheckCircle2,
  MapPin,
  MessageSquare,
  FileText,
  Download,
  Shield,
  AlertCircle,
  ChevronRight,
  Box
} from 'lucide-react';

interface OrderTrackingProps {
  onBack: () => void;
}

interface Order {
  id: string;
  designName: string;
  designerName: string;
  designerAvatar: string;
  orderDate: string;
  estimatedDelivery: string;
  status: 'design' | 'sourcing' | 'production' | 'quality' | 'shipping' | 'delivered';
  progress: number;
  totalPrice: string;
  image: string;
}

interface TrackingEvent {
  id: string;
  status: string;
  description: string;
  date: string;
  time: string;
  completed: boolean;
  icon: React.ElementType;
}

export default function OrderTracking({ onBack }: OrderTrackingProps) {
  const [selectedOrder, setSelectedOrder] = useState<string | null>('ORD-2024-001');

  const orders: Order[] = [
    {
      id: 'ORD-2024-001',
      designName: 'Eternal Radiance Engagement Ring',
      designerName: 'Elena Rodriguez',
      designerAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      orderDate: 'Jan 15, 2024',
      estimatedDelivery: 'Feb 28, 2024',
      status: 'production',
      progress: 60,
      totalPrice: '$8,500',
      image: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=200&h=200&fit=crop',
    },
    {
      id: 'ORD-2024-002',
      designName: 'Vintage Halo Pendant',
      designerName: 'Marcus Chen',
      designerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
      orderDate: 'Dec 20, 2023',
      estimatedDelivery: 'Jan 30, 2024',
      status: 'shipping',
      progress: 85,
      totalPrice: '$4,200',
      image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=200&h=200&fit=crop',
    },
  ];

  const trackingEvents: TrackingEvent[] = [
    {
      id: '1',
      status: 'Design Finalized',
      description: 'Your design has been approved and finalized with Elena Rodriguez',
      date: 'Jan 15, 2024',
      time: '10:30 AM',
      completed: true,
      icon: CheckCircle2,
    },
    {
      id: '2',
      status: 'Diamond Sourced',
      description: '1.5ct Round Brilliant D-color diamond certified by GIA (Cert#: 6213456789)',
      date: 'Jan 18, 2024',
      time: '2:45 PM',
      completed: true,
      icon: CheckCircle2,
    },
    {
      id: '3',
      status: 'In Production',
      description: 'Your ring is being crafted by our master jeweler. Current stage: Setting',
      date: 'Jan 25, 2024',
      time: '9:00 AM',
      completed: true,
      icon: Box,
    },
    {
      id: '4',
      status: 'Quality Control',
      description: 'Final inspection and quality assurance testing',
      date: 'Feb 20, 2024',
      time: 'Estimated',
      completed: false,
      icon: Shield,
    },
    {
      id: '5',
      status: 'Shipping',
      description: 'Fully insured shipping with real-time tracking',
      date: 'Feb 25, 2024',
      time: 'Estimated',
      completed: false,
      icon: Truck,
    },
    {
      id: '6',
      status: 'Delivered',
      description: 'Signature required upon delivery',
      date: 'Feb 28, 2024',
      time: 'Estimated',
      completed: false,
      icon: Package,
    },
  ];

  const activeOrder = orders.find(o => o.id === selectedOrder);

  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 px-4 py-2 rounded-full glass text-white hover:bg-white/10 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
          <h1 className="text-2xl lg:text-3xl font-bold text-white">Order Tracking</h1>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Orders List */}
          <div className="lg:col-span-1 space-y-4">
            <h2 className="text-lg font-semibold text-white mb-4">Your Orders</h2>
            {orders.map((order) => (
              <button
                key={order.id}
                onClick={() => setSelectedOrder(order.id)}
                className={`w-full glass-card rounded-xl p-4 text-left transition-all duration-300 ${
                  selectedOrder === order.id
                    ? 'border-[#D4AF37]/50 bg-[#D4AF37]/5'
                    : 'hover:border-[#D4AF37]/30'
                }`}
              >
                <div className="flex gap-4">
                  <img
                    src={order.image}
                    alt={order.designName}
                    className="w-20 h-20 rounded-lg object-cover"
                  />
                  <div className="flex-1">
                    <p className="text-xs text-slate-400 mb-1">{order.id}</p>
                    <h3 className="text-sm font-medium text-white line-clamp-2">{order.designName}</h3>
                    <div className="flex items-center gap-2 mt-2">
                      <img
                        src={order.designerAvatar}
                        alt={order.designerName}
                        className="w-5 h-5 rounded-full object-cover"
                      />
                      <span className="text-xs text-slate-400">{order.designerName}</span>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-[#D4AF37] font-semibold text-sm">{order.totalPrice}</span>
                      <Badge 
                        className={`text-xs ${
                          order.status === 'delivered' 
                            ? 'bg-green-500/20 text-green-400' 
                            : 'bg-[#D4AF37]/20 text-[#D4AF37]'
                        }`}
                      >
                        {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                      </Badge>
                    </div>
                  </div>
                </div>
              </button>
            ))}

            {/* Support Card */}
            <div className="glass-card rounded-xl p-6 mt-6">
              <h3 className="font-semibold text-white mb-2">Need Help?</h3>
              <p className="text-sm text-slate-400 mb-4">
                Our support team is available 24/7 to assist you with your order.
              </p>
              <Button
                variant="outline"
                className="w-full border-[#D4AF37]/30 text-[#D4AF37]"
              >
                <MessageSquare className="w-4 h-4 mr-2" />
                Contact Support
              </Button>
            </div>
          </div>

          {/* Order Details */}
          {activeOrder && (
            <div className="lg:col-span-2 space-y-6">
              {/* Order Summary */}
              <div className="glass-card rounded-xl p-6">
                <div className="flex flex-col md:flex-row gap-6">
                  <img
                    src={activeOrder.image}
                    alt={activeOrder.designName}
                    className="w-full md:w-48 h-48 rounded-xl object-cover"
                  />
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <p className="text-sm text-slate-400 mb-1">{activeOrder.id}</p>
                        <h2 className="text-xl font-bold text-white">{activeOrder.designName}</h2>
                      </div>
                      <Badge className="bg-[#D4AF37]/20 text-[#D4AF37]">
                        {activeOrder.status.charAt(0).toUpperCase() + activeOrder.status.slice(1)}
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div>
                        <p className="text-xs text-slate-400 mb-1">Designer</p>
                        <div className="flex items-center gap-2">
                          <img
                            src={activeOrder.designerAvatar}
                            alt={activeOrder.designerName}
                            className="w-6 h-6 rounded-full object-cover"
                          />
                          <span className="text-sm text-white">{activeOrder.designerName}</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-xs text-slate-400 mb-1">Order Date</p>
                        <p className="text-sm text-white">{activeOrder.orderDate}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-400 mb-1">Est. Delivery</p>
                        <p className="text-sm text-white">{activeOrder.estimatedDelivery}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-400 mb-1">Total</p>
                        <p className="text-sm text-[#D4AF37] font-semibold">{activeOrder.totalPrice}</p>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-slate-400">Order Progress</span>
                        <span className="text-sm text-[#D4AF37]">{activeOrder.progress}%</span>
                      </div>
                      <div className="h-2 rounded-full bg-[#0F172A] overflow-hidden">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-[#D4AF37] to-[#00FFFF] transition-all duration-500"
                          style={{ width: `${activeOrder.progress}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Tracking Timeline */}
              <div className="glass-card rounded-xl p-6">
                <h3 className="text-lg font-semibold text-white mb-6">Tracking Timeline</h3>
                <div className="space-y-6">
                  {trackingEvents.map((event, index) => (
                    <div key={event.id} className="relative">
                      {/* Connector Line */}
                      {index < trackingEvents.length - 1 && (
                        <div
                          className={`absolute left-5 top-10 w-0.5 h-full ${
                            event.completed ? 'bg-[#D4AF37]' : 'bg-slate-700'
                          }`}
                        />
                      )}

                      <div className="flex gap-4">
                        {/* Icon */}
                        <div
                          className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                            event.completed
                              ? 'bg-[#D4AF37] text-black'
                              : 'bg-slate-800 text-slate-500'
                          }`}
                        >
                          <event.icon className="w-5 h-5" />
                        </div>

                        {/* Content */}
                        <div className="flex-1 pb-6">
                          <div className="flex items-start justify-between">
                            <div>
                              <h4 className={`font-medium ${event.completed ? 'text-white' : 'text-slate-400'}`}>
                                {event.status}
                              </h4>
                              <p className="text-sm text-slate-400 mt-1">{event.description}</p>
                            </div>
                            <div className="text-right">
                              <p className="text-sm text-slate-400">{event.date}</p>
                              <p className="text-xs text-slate-500">{event.time}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Documents & Actions */}
              <div className="grid md:grid-cols-2 gap-6">
                <div className="glass-card rounded-xl p-6">
                  <h3 className="text-lg font-semibold text-white mb-4">Documents</h3>
                  <div className="space-y-3">
                    <button className="w-full flex items-center gap-3 p-3 rounded-lg bg-[#0F172A] hover:bg-[#D4AF37]/10 transition-colors">
                      <FileText className="w-5 h-5 text-[#D4AF37]" />
                      <div className="flex-1 text-left">
                        <p className="text-sm text-white">Order Confirmation</p>
                        <p className="text-xs text-slate-400">PDF • 245 KB</p>
                      </div>
                      <Download className="w-4 h-4 text-slate-400" />
                    </button>
                    <button className="w-full flex items-center gap-3 p-3 rounded-lg bg-[#0F172A] hover:bg-[#D4AF37]/10 transition-colors">
                      <Shield className="w-5 h-5 text-[#00FFFF]" />
                      <div className="flex-1 text-left">
                        <p className="text-sm text-white">GIA Certificate</p>
                        <p className="text-xs text-slate-400">PDF • 1.2 MB</p>
                      </div>
                      <Download className="w-4 h-4 text-slate-400" />
                    </button>
                    <button className="w-full flex items-center gap-3 p-3 rounded-lg bg-[#0F172A] hover:bg-[#D4AF37]/10 transition-colors">
                      <FileText className="w-5 h-5 text-[#D4AF37]" />
                      <div className="flex-1 text-left">
                        <p className="text-sm text-white">Insurance Document</p>
                        <p className="text-xs text-slate-400">PDF • 890 KB</p>
                      </div>
                      <Download className="w-4 h-4 text-slate-400" />
                    </button>
                  </div>
                </div>

                <div className="glass-card rounded-xl p-6">
                  <h3 className="text-lg font-semibold text-white mb-4">Quick Actions</h3>
                  <div className="space-y-3">
                    <Button
                      variant="outline"
                      className="w-full border-[#D4AF37]/30 text-[#D4AF37] justify-between"
                    >
                      <span className="flex items-center">
                        <MessageSquare className="w-4 h-4 mr-2" />
                        Message Designer
                      </span>
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full border-[#D4AF37]/30 text-[#D4AF37] justify-between"
                    >
                      <span className="flex items-center">
                        <MapPin className="w-4 h-4 mr-2" />
                        Track Shipment
                      </span>
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full border-red-400/30 text-red-400 justify-between"
                    >
                      <span className="flex items-center">
                        <AlertCircle className="w-4 h-4 mr-2" />
                        Report Issue
                      </span>
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
