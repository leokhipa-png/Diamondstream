import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  ArrowLeft, 
  MapPin, 
  Star, 
  Award, 
  Verified, 
  MessageSquare, 
  Calendar,
  Heart,
  Share2,
  CheckCircle2,
  TrendingUp,
  Clock,
  Globe,
  Phone,
  Mail
} from 'lucide-react';

interface DesignerProfileProps {
  designerId: string;
  onBack: () => void;
  onOpenAuth: (mode: 'login' | 'signup') => void;
  isLoggedIn: boolean;
}

export default function DesignerProfile({ designerId, onBack, onOpenAuth, isLoggedIn }: DesignerProfileProps) {
  // Mock designer data - in real app, fetch based on designerId
  const designer = {
    id: designerId,
    name: 'Elena Rodriguez',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop',
    coverImage: 'https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?w=1200&h=400&fit=crop',
    location: 'New York, USA',
    specialty: 'Engagement Rings',
    rating: 4.9,
    reviews: 127,
    completedProjects: 342,
    isVerified: true,
    isPremium: true,
    isOnline: true,
    bio: 'Award-winning jewelry designer with over 15 years of experience creating bespoke engagement rings and fine jewelry. Trained at the Gemological Institute of America and winner of the 2022 International Jewelry Design Excellence Award. My passion lies in transforming love stories into timeless pieces that will be cherished for generations.',
    startingPrice: '$3,500',
    languages: ['English', 'Spanish', 'Italian'],
    experience: '15+ years',
    responseTime: '< 2 hours',
    portfolio: [
      'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1603561591411-07134e71a2a9?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1602751584552-8ba420552259?w=400&h=400&fit=crop',
      'https://images.unsplash.com/photo-1617038220319-276d3cfab638?w=400&h=400&fit=crop',
    ],
    services: [
      { name: 'Custom Engagement Rings', price: 'From $3,500', duration: '4-6 weeks' },
      { name: 'Wedding Bands', price: 'From $1,200', duration: '2-3 weeks' },
      { name: 'Anniversary Gifts', price: 'From $2,000', duration: '3-4 weeks' },
      { name: 'Redesign & Restoration', price: 'From $800', duration: '2-4 weeks' },
    ],
    reviewList: [
      {
        id: '1',
        customer: 'Sarah Mitchell',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=50&h=50&fit=crop',
        rating: 5,
        date: '2 weeks ago',
        text: 'Elena created the most beautiful engagement ring for my fiancée. The attention to detail and craftsmanship is incredible. She listened to every request and exceeded our expectations!',
        designImage: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=200&h=200&fit=crop',
      },
      {
        id: '2',
        customer: 'James Thompson',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop',
        rating: 5,
        date: '1 month ago',
        text: 'Working with Elena was a dream. She understood exactly what I wanted for my wife\'s anniversary gift. The vintage-inspired necklace she created is absolutely stunning.',
        designImage: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=200&h=200&fit=crop',
      },
      {
        id: '3',
        customer: 'Maria Garcia',
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=50&h=50&fit=crop',
        rating: 5,
        date: '2 months ago',
        text: 'Elena redesigned my grandmother\'s ring into a modern piece while preserving its sentimental value. Her respect for the original design while adding her touch was masterful.',
        designImage: 'https://images.unsplash.com/photo-1603561591411-07134e71a2a9?w=200&h=200&fit=crop',
      },
    ],
    certifications: [
      'GIA Graduate Gemologist',
      'Jewelry Design Excellence Award 2022',
      'Ethical Jewelry Association Member',
    ],
  };

  return (
    <div className="min-h-screen pt-20 pb-12">
      {/* Cover Image */}
      <div className="relative h-64 lg:h-80">
        <img
          src={designer.coverImage}
          alt={`${designer.name} cover`}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#050A14] via-[#050A14]/50 to-transparent" />
        
        {/* Back Button */}
        <button
          onClick={onBack}
          className="absolute top-6 left-6 flex items-center gap-2 px-4 py-2 rounded-full glass text-white hover:bg-white/10 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Designers
        </button>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-20 relative z-10">
        {/* Profile Header */}
        <div className="glass-card rounded-2xl p-6 lg:p-8 mb-8">
          <div className="flex flex-col lg:flex-row gap-6">
            {/* Avatar */}
            <div className="relative">
              <img
                src={designer.avatar}
                alt={designer.name}
                className="w-32 h-32 lg:w-40 lg:h-40 rounded-2xl object-cover border-4 border-[#D4AF37]/30"
              />
              {designer.isOnline && (
                <span className="absolute -bottom-2 -right-2 w-6 h-6 bg-green-500 rounded-full border-4 border-[#0F172A]" />
              )}
            </div>

            {/* Info */}
            <div className="flex-1">
              <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h1 className="text-2xl lg:text-3xl font-bold text-white">{designer.name}</h1>
                    {designer.isVerified && (
                      <Badge className="bg-green-500/80 text-white">
                        <Verified className="w-3 h-3 mr-1" />
                        Verified
                      </Badge>
                    )}
                    {designer.isPremium && (
                      <Badge className="bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-black">
                        <Award className="w-3 h-3 mr-1" />
                        Premium
                      </Badge>
                    )}
                  </div>
                  <p className="text-slate-400 flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    {designer.location}
                  </p>
                </div>
                
                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    size="icon"
                    className="border-[#D4AF37]/30 text-[#D4AF37]"
                  >
                    <Heart className="w-5 h-5" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    className="border-[#D4AF37]/30 text-[#D4AF37]"
                  >
                    <Share2 className="w-5 h-5" />
                  </Button>
                  {isLoggedIn ? (
                    <Button className="bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-black font-medium">
                      <MessageSquare className="w-4 h-4 mr-2" />
                      Message
                    </Button>
                  ) : (
                    <Button
                      onClick={() => onOpenAuth('login')}
                      className="bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-black font-medium"
                    >
                      <MessageSquare className="w-4 h-4 mr-2" />
                      Connect
                    </Button>
                  )}
                </div>
              </div>

              {/* Stats */}
              <div className="flex flex-wrap gap-6 mb-4">
                <div className="flex items-center gap-2">
                  <Star className="w-5 h-5 text-[#D4AF37] fill-[#D4AF37]" />
                  <span className="text-white font-semibold">{designer.rating}</span>
                  <span className="text-slate-400">({designer.reviews} reviews)</span>
                </div>
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-[#00FFFF]" />
                  <span className="text-white font-semibold">{designer.completedProjects}</span>
                  <span className="text-slate-400">projects</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-[#D4AF37]" />
                  <span className="text-slate-400">Responds {designer.responseTime}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Globe className="w-5 h-5 text-[#00FFFF]" />
                  <span className="text-slate-400">{designer.languages.join(', ')}</span>
                </div>
              </div>

              {/* Bio */}
              <p className="text-slate-300 leading-relaxed">{designer.bio}</p>

              {/* Certifications */}
              <div className="flex flex-wrap gap-2 mt-4">
                {designer.certifications.map((cert, index) => (
                  <Badge
                    key={index}
                    variant="outline"
                    className="border-[#D4AF37]/30 text-[#D4AF37]"
                  >
                    <CheckCircle2 className="w-3 h-3 mr-1" />
                    {cert}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Tabs Content */}
        <Tabs defaultValue="portfolio" className="space-y-8">
          <TabsList className="glass-card p-1 flex flex-wrap">
            <TabsTrigger value="portfolio" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">
              Portfolio
            </TabsTrigger>
            <TabsTrigger value="services" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">
              Services
            </TabsTrigger>
            <TabsTrigger value="reviews" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">
              Reviews
            </TabsTrigger>
            <TabsTrigger value="about" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">
              About
            </TabsTrigger>
          </TabsList>

          <TabsContent value="portfolio" className="space-y-6">
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {designer.portfolio.map((image, index) => (
                <div
                  key={index}
                  className="group relative aspect-square rounded-xl overflow-hidden cursor-pointer"
                >
                  <img
                    src={image}
                    alt={`Portfolio piece ${index + 1}`}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="absolute bottom-4 left-4 right-4">
                      <p className="text-white font-medium">Design #{index + 1}</p>
                      <p className="text-sm text-slate-400">Click to view details</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="services" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {designer.services.map((service, index) => (
                <div key={index} className="glass-card rounded-xl p-6">
                  <h3 className="text-lg font-semibold text-white mb-2">{service.name}</h3>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-[#D4AF37] font-semibold">{service.price}</span>
                    <span className="text-sm text-slate-400 flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {service.duration}
                    </span>
                  </div>
                  <Button className="w-full bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-black font-medium">
                    Request Quote
                  </Button>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="reviews" className="space-y-6">
            <div className="grid gap-6">
              {designer.reviewList.map((review) => (
                <div key={review.id} className="glass-card rounded-xl p-6">
                  <div className="flex items-start gap-4">
                    <img
                      src={review.avatar}
                      alt={review.customer}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <div>
                          <h4 className="font-semibold text-white">{review.customer}</h4>
                          <p className="text-sm text-slate-400">{review.date}</p>
                        </div>
                        <div className="flex items-center gap-1">
                          {[...Array(review.rating)].map((_, i) => (
                            <Star key={i} className="w-4 h-4 text-[#D4AF37] fill-[#D4AF37]" />
                          ))}
                        </div>
                      </div>
                      <p className="text-slate-300 mb-4">{review.text}</p>
                      <img
                        src={review.designImage}
                        alt="Design"
                        className="w-32 h-32 rounded-lg object-cover"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="about" className="space-y-6">
            <div className="glass-card rounded-xl p-8">
              <h3 className="text-xl font-semibold text-white mb-6">Contact Information</h3>
              <div className="grid sm:grid-cols-2 gap-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-lg bg-[#D4AF37]/10 flex items-center justify-center">
                    <Mail className="w-5 h-5 text-[#D4AF37]" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-400">Email</p>
                    <p className="text-white">elena@rodriguezdesigns.com</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-lg bg-[#D4AF37]/10 flex items-center justify-center">
                    <Phone className="w-5 h-5 text-[#D4AF37]" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-400">Phone</p>
                    <p className="text-white">+1 (555) 123-4567</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-lg bg-[#D4AF37]/10 flex items-center justify-center">
                    <MapPin className="w-5 h-5 text-[#D4AF37]" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-400">Studio</p>
                    <p className="text-white">Diamond District, NYC</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-lg bg-[#D4AF37]/10 flex items-center justify-center">
                    <Calendar className="w-5 h-5 text-[#D4AF37]" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-400">Experience</p>
                    <p className="text-white">{designer.experience}</p>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
