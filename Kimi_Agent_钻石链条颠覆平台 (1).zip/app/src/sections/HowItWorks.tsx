import { useState } from 'react';
import { 
  Sparkles, 
  MessageSquare, 
  Gem, 
  Truck, 
  Star,
  ArrowRight,
  CheckCircle2,
  Shield,
  Wallet
} from 'lucide-react';

const steps = [
  {
    id: 1,
    icon: Sparkles,
    title: 'AI Design Generation',
    description: 'Describe your dream jewelry or upload inspiration images. Our AI generates unique designs tailored to your preferences, budget, and style.',
    details: [
      'Input your vision with natural language',
      'Adjust parameters: carat, cut, color, clarity',
      'Get 4+ unique design variations instantly',
      'Save and compare your favorite designs',
    ],
    color: '#D4AF37',
  },
  {
    id: 2,
    icon: MessageSquare,
    title: 'Designer Consultation',
    description: 'Connect directly with verified jewelry designers. Discuss your design, get expert advice, and refine every detail through real-time chat.',
    details: [
      'Browse designer portfolios and reviews',
      'Request video consultations',
      'Negotiate pricing and timelines',
      'Finalize design specifications',
    ],
    color: '#00FFFF',
  },
  {
    id: 3,
    icon: Gem,
    title: 'Diamond Sourcing',
    description: 'Our verified dealers provide certified diamonds with complete provenance. Every stone is ethically sourced and comes with GIA/IGI certification.',
    details: [
      'Access to global diamond inventory',
      'GIA, IGI, HRD certified stones only',
      'Transparent pricing with no markup',
      'Conflict-free guarantee',
    ],
    color: '#D4AF37',
  },
  {
    id: 4,
    icon: Shield,
    title: 'Crafting & Quality Control',
    description: 'Expert manufacturers bring your design to life. Every piece undergoes rigorous quality checks at multiple stages.',
    details: [
      'Master craftsmen with 20+ years experience',
      'Real-time production updates',
      'Multi-stage quality inspection',
      'Professional photography before shipping',
    ],
    color: '#00FFFF',
  },
  {
    id: 5,
    icon: Wallet,
    title: 'Secure Payment',
    description: 'Pay securely through our escrow system. Funds are released to the designer only when you approve the final piece.',
    details: [
      'Escrow protection for all transactions',
      'Multiple payment methods accepted',
      'International wire transfers',
      'Cryptocurrency payments available',
    ],
    color: '#D4AF37',
  },
  {
    id: 6,
    icon: Truck,
    title: 'Insured Delivery',
    description: 'Your jewelry is shipped with full insurance and tracking. Signature required delivery ensures safe arrival.',
    details: [
      'Fully insured global shipping',
      'Real-time tracking updates',
      'Discrete packaging',
      'Certificate of authenticity included',
    ],
    color: '#00FFFF',
  },
];

export default function HowItWorks() {
  const [activeStep, setActiveStep] = useState(1);

  return (
    <section id="how-it-works" className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-[#D4AF37]/5 rounded-full blur-[150px]" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-[#00FFFF]/30 mb-6">
            <CheckCircle2 className="w-4 h-4 text-[#00FFFF]" />
            <span className="text-sm text-slate-300">How It Works</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            From <span className="text-gradient-gold">Vision</span> to <span className="text-cyan">Reality</span>
          </h2>
          <p className="text-lg text-slate-400 max-w-2xl mx-auto">
            Our transparent process connects you with the best designers, dealers, and manufacturers 
            to create your perfect piece of jewelry.
          </p>
        </div>

        {/* Process Flow */}
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Left - Step Navigation */}
          <div className="space-y-4">
            {steps.map((step, index) => (
              <button
                key={step.id}
                onClick={() => setActiveStep(step.id)}
                className={`w-full text-left p-5 rounded-xl border transition-all duration-300 ${
                  activeStep === step.id
                    ? 'border-[#D4AF37]/50 bg-[#D4AF37]/5'
                    : 'border-[#D4AF37]/10 hover:border-[#D4AF37]/30 bg-[#0F172A]/50'
                }`}
              >
                <div className="flex items-center gap-4">
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all duration-300 ${
                      activeStep === step.id ? 'scale-110' : ''
                    }`}
                    style={{
                      background: `linear-gradient(135deg, ${step.color}20 0%, ${step.color}10 100%)`,
                    }}
                  >
                    <step.icon
                      className="w-6 h-6"
                      style={{ color: step.color }}
                    />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span
                        className="text-sm font-medium"
                        style={{ color: step.color }}
                      >
                        Step {index + 1}
                      </span>
                      {activeStep === step.id && (
                        <ArrowRight className="w-4 h-4 text-[#D4AF37]" />
                      )}
                    </div>
                    <h3 className={`font-semibold ${activeStep === step.id ? 'text-white' : 'text-slate-400'}`}>
                      {step.title}
                    </h3>
                  </div>
                </div>
              </button>
            ))}
          </div>

          {/* Right - Active Step Details */}
          <div className="lg:sticky lg:top-32">
            {steps.map((step) => (
              <div
                key={step.id}
                className={`${activeStep === step.id ? 'block' : 'hidden'} animate-fadeInUp`}
              >
                <div className="glass-card rounded-2xl p-8">
                  <div
                    className="w-20 h-20 rounded-2xl flex items-center justify-center mb-6"
                    style={{
                      background: `linear-gradient(135deg, ${step.color}30 0%, ${step.color}10 100%)`,
                      boxShadow: `0 0 40px ${step.color}20`,
                    }}
                  >
                    <step.icon className="w-10 h-10" style={{ color: step.color }} />
                  </div>

                  <h3 className="text-2xl font-bold text-white mb-4">{step.title}</h3>
                  <p className="text-slate-400 mb-8 leading-relaxed">{step.description}</p>

                  <div className="space-y-4">
                    <p className="text-sm text-slate-500 uppercase tracking-wider">What&apos;s Included</p>
                    {step.details.map((detail, i) => (
                      <div
                        key={i}
                        className="flex items-start gap-3 p-3 rounded-lg bg-[#0F172A]/50"
                      >
                        <CheckCircle2
                          className="w-5 h-5 mt-0.5 flex-shrink-0"
                          style={{ color: step.color }}
                        />
                        <span className="text-slate-300">{detail}</span>
                      </div>
                    ))}
                  </div>

                  {/* Progress Indicator */}
                  <div className="mt-8 pt-6 border-t border-[#D4AF37]/10">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-500">Progress</span>
                      <span className="text-[#D4AF37]">{Math.round((step.id / steps.length) * 100)}%</span>
                    </div>
                    <div className="mt-2 h-2 rounded-full bg-[#0F172A] overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${(step.id / steps.length) * 100}%`,
                          background: `linear-gradient(90deg, ${step.color} 0%, ${step.color}80 100%)`,
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Trust Badges */}
        <div className="mt-20 grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { icon: Shield, label: 'Escrow Protection', desc: 'Secure payments' },
            { icon: Star, label: 'Verified Network', desc: 'Vetted professionals' },
            { icon: CheckCircle2, label: 'Quality Guarantee', desc: '100% satisfaction' },
            { icon: Truck, label: 'Insured Shipping', desc: 'Full coverage' },
          ].map((badge, index) => (
            <div
              key={badge.label}
              className="flex items-center gap-4 p-4 rounded-xl glass-card"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[#D4AF37]/20 to-[#00FFFF]/20 flex items-center justify-center">
                <badge.icon className="w-6 h-6 text-[#D4AF37]" />
              </div>
              <div>
                <p className="font-medium text-white">{badge.label}</p>
                <p className="text-sm text-slate-400">{badge.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
