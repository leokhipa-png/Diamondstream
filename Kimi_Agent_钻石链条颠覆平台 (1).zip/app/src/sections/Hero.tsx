import { useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Sparkles, ArrowRight, Shield, Zap, Globe } from 'lucide-react';

interface HeroProps {
  onOpenAuth: (mode: 'login' | 'signup') => void;
}

export default function Hero({ onOpenAuth }: HeroProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Animated diamond canvas effect
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = canvas.offsetWidth * window.devicePixelRatio;
      canvas.height = canvas.offsetHeight * window.devicePixelRatio;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    };
    resize();
    window.addEventListener('resize', resize);

    let animationId: number;
    let rotation = 0;
    const sparkles: Array<{ x: number; y: number; size: number; opacity: number; speed: number }> = [];

    // Create sparkles
    for (let i = 0; i < 30; i++) {
      sparkles.push({
        x: Math.random() * canvas.offsetWidth,
        y: Math.random() * canvas.offsetHeight,
        size: Math.random() * 3 + 1,
        opacity: Math.random(),
        speed: Math.random() * 0.02 + 0.01,
      });
    }

    const drawDiamond = () => {
      const centerX = canvas.offsetWidth / 2;
      const centerY = canvas.offsetHeight / 2;
      const size = Math.min(canvas.offsetWidth, canvas.offsetHeight) * 0.35;

      ctx.clearRect(0, 0, canvas.offsetWidth, canvas.offsetHeight);

      // Draw sparkles
      sparkles.forEach((sparkle) => {
        sparkle.opacity += sparkle.speed;
        if (sparkle.opacity > 1 || sparkle.opacity < 0) {
          sparkle.speed = -sparkle.speed;
        }
        ctx.beginPath();
        ctx.arc(sparkle.x, sparkle.y, sparkle.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(212, 175, 55, ${Math.abs(sparkle.opacity) * 0.8})`;
        ctx.fill();
      });

      // Draw diamond shape with rotation
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(rotation);

      // Diamond facets
      const facets = [
        { points: [[0, -size], [size * 0.5, -size * 0.3], [0, 0]], color: 'rgba(255, 255, 255, 0.9)' },
        { points: [[0, -size], [-size * 0.5, -size * 0.3], [0, 0]], color: 'rgba(240, 248, 255, 0.7)' },
        { points: [[size * 0.5, -size * 0.3], [size * 0.8, 0], [0, 0]], color: 'rgba(212, 175, 55, 0.4)' },
        { points: [[-size * 0.5, -size * 0.3], [-size * 0.8, 0], [0, 0]], color: 'rgba(212, 175, 55, 0.3)' },
        { points: [[size * 0.8, 0], [size * 0.4, size * 0.5], [0, 0]], color: 'rgba(0, 255, 255, 0.2)' },
        { points: [[-size * 0.8, 0], [-size * 0.4, size * 0.5], [0, 0]], color: 'rgba(0, 255, 255, 0.15)' },
        { points: [[size * 0.4, size * 0.5], [0, size * 0.8], [0, 0]], color: 'rgba(212, 175, 55, 0.5)' },
        { points: [[-size * 0.4, size * 0.5], [0, size * 0.8], [0, 0]], color: 'rgba(212, 175, 55, 0.4)' },
      ];

      facets.forEach((facet) => {
        ctx.beginPath();
        ctx.moveTo(facet.points[0][0], facet.points[0][1]);
        ctx.lineTo(facet.points[1][0], facet.points[1][1]);
        ctx.lineTo(facet.points[2][0], facet.points[2][1]);
        ctx.closePath();
        ctx.fillStyle = facet.color;
        ctx.fill();
        ctx.strokeStyle = 'rgba(212, 175, 55, 0.3)';
        ctx.stroke();
      });

      // Inner facets for depth
      ctx.beginPath();
      ctx.moveTo(0, -size * 0.3);
      ctx.lineTo(size * 0.3, 0);
      ctx.lineTo(0, size * 0.5);
      ctx.lineTo(-size * 0.3, 0);
      ctx.closePath();
      ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
      ctx.fill();

      ctx.restore();

      // Glow effect
      const gradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, size * 1.5);
      gradient.addColorStop(0, 'rgba(212, 175, 55, 0.2)');
      gradient.addColorStop(0.5, 'rgba(0, 255, 255, 0.1)');
      gradient.addColorStop(1, 'transparent');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.offsetWidth, canvas.offsetHeight);

      rotation += 0.005;
      animationId = requestAnimationFrame(drawDiamond);
    };

    drawDiamond();

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationId);
    };
  }, []);

  return (
    <section id="hero" className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#D4AF37]/10 rounded-full blur-[100px] animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#00FFFF]/10 rounded-full blur-[100px] animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-radial from-[#D4AF37]/5 to-transparent rounded-full" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8 animate-fadeInUp">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-[#D4AF37]/30">
              <Sparkles className="w-4 h-4 text-[#D4AF37]" />
              <span className="text-sm text-slate-300">AI-Powered Jewelry Design</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight">
              <span className="text-white">The Future of</span>
              <br />
              <span className="text-gradient-gold">Luxury Jewelry</span>
              <br />
              <span className="text-white">is Here</span>
            </h1>

            <p className="text-lg text-slate-400 max-w-lg">
              Design your dream jewelry with AI, connect directly with world-class designers, 
              and track every step from concept to delivery. Transparent, ethical, and uniquely yours.
            </p>

            <div className="flex flex-wrap gap-4">
              <Button
                size="lg"
                onClick={() => onOpenAuth('signup')}
                className="bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-black font-semibold hover:shadow-xl hover:shadow-[#D4AF37]/30 transition-all duration-300 group"
              >
                Start Designing
                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => document.getElementById('designers')?.scrollIntoView({ behavior: 'smooth' })}
                className="border-[#D4AF37]/50 text-[#D4AF37] hover:bg-[#D4AF37]/10"
              >
                Explore Designers
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 pt-8 border-t border-[#D4AF37]/20">
              <div>
                <p className="text-2xl font-bold text-gradient-gold">500+</p>
                <p className="text-sm text-slate-400">Verified Designers</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-gradient-gold">10K+</p>
                <p className="text-sm text-slate-400">Custom Designs</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-gradient-gold">50+</p>
                <p className="text-sm text-slate-400">Countries Served</p>
              </div>
            </div>
          </div>

          {/* Right Content - Animated Diamond */}
          <div className="relative flex items-center justify-center animate-float">
            <canvas
              ref={canvasRef}
              className="w-full max-w-lg aspect-square"
              style={{ filter: 'drop-shadow(0 0 60px rgba(212, 175, 55, 0.3))' }}
            />
          </div>
        </div>

        {/* Features Bar */}
        <div className="mt-20 grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { icon: Zap, title: 'AI Design Studio', desc: 'Generate unique designs in seconds' },
            { icon: Shield, title: 'Verified Network', desc: 'Every partner is thoroughly vetted' },
            { icon: Globe, title: 'Global Delivery', desc: 'Ship to anywhere in the world' },
            { icon: Sparkles, title: 'Ethical Sourcing', desc: '100% conflict-free diamonds' },
          ].map((feature, index) => (
            <div
              key={feature.title}
              className="p-6 rounded-xl glass-card hover:border-[#D4AF37]/40 transition-all duration-300 group"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[#D4AF37]/20 to-[#00FFFF]/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <feature.icon className="w-6 h-6 text-[#D4AF37]" />
              </div>
              <h3 className="font-semibold text-white mb-1">{feature.title}</h3>
              <p className="text-sm text-slate-400">{feature.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
