import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { 
  MessageSquare, 
  Phone, 
  Video, 
  Send, 
  Paperclip, 
  Mic,
  MoreVertical,
  PhoneCall,
  VideoIcon,
  CheckCheck,
  Shield,
  Lock
} from 'lucide-react';

interface Message {
  id: string;
  sender: 'customer' | 'designer';
  text: string;
  timestamp: string;
  status: 'sent' | 'delivered' | 'read';
  attachments?: string[];
}

interface Conversation {
  id: string;
  designer: {
    name: string;
    avatar: string;
    specialty: string;
    isOnline: boolean;
  };
  lastMessage: string;
  timestamp: string;
  unread: number;
  messages: Message[];
}

interface CommunicationHubProps {
  isLoggedIn: boolean;
  onOpenAuth: (mode: 'login' | 'signup') => void;
}

export default function CommunicationHub({ isLoggedIn, onOpenAuth }: CommunicationHubProps) {
  const [activeConversation, setActiveConversation] = useState<string | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const conversations: Conversation[] = [
    {
      id: '1',
      designer: {
        name: 'Elena Rodriguez',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
        specialty: 'Engagement Rings',
        isOnline: true,
      },
      lastMessage: 'I\'ve prepared the 3D render of your design. What do you think?',
      timestamp: '2 min ago',
      unread: 2,
      messages: [
        {
          id: '1',
          sender: 'customer',
          text: 'Hi Elena! I love the vintage halo design you showed me. Can we make the center stone a bit larger?',
          timestamp: 'Yesterday, 3:45 PM',
          status: 'read',
        },
        {
          id: '2',
          sender: 'designer',
          text: 'Absolutely! I can increase it to 1.5 carats while maintaining the proportions. Let me create a new render for you.',
          timestamp: 'Yesterday, 4:02 PM',
          status: 'read',
        },
        {
          id: '3',
          sender: 'designer',
          text: 'I\'ve prepared the 3D render of your design. What do you think?',
          timestamp: '2 min ago',
          status: 'delivered',
          attachments: ['https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=400&h=400&fit=crop'],
        },
      ],
    },
    {
      id: '2',
      designer: {
        name: 'Marcus Chen',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
        specialty: 'Contemporary Designs',
        isOnline: false,
      },
      lastMessage: 'The diamonds have been sourced. GIA certificates attached.',
      timestamp: '1 hour ago',
      unread: 0,
      messages: [
        {
          id: '1',
          sender: 'designer',
          text: 'The diamonds have been sourced. GIA certificates attached.',
          timestamp: '1 hour ago',
          status: 'read',
        },
      ],
    },
    {
      id: '3',
      designer: {
        name: 'Sofia Andersson',
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
        specialty: 'Vintage & Antique',
        isOnline: true,
      },
      lastMessage: 'Thank you for choosing me for your special piece!',
      timestamp: '2 days ago',
      unread: 0,
      messages: [],
    },
  ];

  const activeChat = conversations.find(c => c.id === activeConversation);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [activeConversation, conversations]);

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;
    // In a real app, this would send the message to the backend
    setNewMessage('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!isLoggedIn) {
    return (
      <section id="communication" className="relative py-24 overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-[#00FFFF]/5 rounded-full blur-[100px]" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-[#D4AF37]/30 mb-6">
              <MessageSquare className="w-4 h-4 text-[#D4AF37]" />
              <span className="text-sm text-slate-300">Communication Hub</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
              Seamless <span className="text-gradient-gold">Communication</span>
            </h2>
            <p className="text-lg text-slate-400 max-w-2xl mx-auto">
              Chat, call, and video conference with your designer in real-time. 
              All communications are encrypted and recorded for your protection.
            </p>
          </div>

          <div className="glass-card rounded-2xl p-12 text-center">
            <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-[#D4AF37]/20 to-[#00FFFF]/20 flex items-center justify-center">
              <Lock className="w-10 h-10 text-[#D4AF37]" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">Secure Communication Platform</h3>
            <p className="text-slate-400 max-w-lg mx-auto mb-8">
              Sign in to access our encrypted messaging system, schedule video calls with designers, 
              and track all your conversations in one place.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button
                onClick={() => onOpenAuth('login')}
                className="bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-black font-medium"
              >
                Sign In to Access
              </Button>
              <Button
                variant="outline"
                onClick={() => onOpenAuth('signup')}
                className="border-[#D4AF37]/30 text-[#D4AF37]"
              >
                Create Account
              </Button>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="communication" className="relative py-24 overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-[#00FFFF]/5 rounded-full blur-[100px]" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-[#D4AF37]/30 mb-6">
            <MessageSquare className="w-4 h-4 text-[#D4AF37]" />
            <span className="text-sm text-slate-300">Communication Hub</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Seamless <span className="text-gradient-gold">Communication</span>
          </h2>
          <p className="text-lg text-slate-400 max-w-2xl mx-auto">
            Chat, call, and video conference with your designer in real-time. 
            All communications are encrypted and recorded for your protection.
          </p>
        </div>

        {/* Chat Interface */}
        <div className="glass-card rounded-2xl overflow-hidden">
          <div className="grid lg:grid-cols-3 h-[600px]">
            {/* Conversations List */}
            <div className="border-r border-[#D4AF37]/10">
              <div className="p-4 border-b border-[#D4AF37]/10">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-white">Messages</h3>
                  <Badge className="bg-[#D4AF37] text-black">3</Badge>
                </div>
              </div>
              <div className="overflow-y-auto h-[calc(600px-65px)]">
                {conversations.map((conv) => (
                  <button
                    key={conv.id}
                    onClick={() => setActiveConversation(conv.id)}
                    className={`w-full p-4 flex items-start gap-3 hover:bg-[#D4AF37]/5 transition-colors ${
                      activeConversation === conv.id ? 'bg-[#D4AF37]/10 border-l-2 border-[#D4AF37]' : ''
                    }`}
                  >
                    <div className="relative">
                      <Avatar className="w-12 h-12">
                        <AvatarImage src={conv.designer.avatar} />
                        <AvatarFallback>{conv.designer.name[0]}</AvatarFallback>
                      </Avatar>
                      {conv.designer.isOnline && (
                        <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-[#0F172A]" />
                      )}
                    </div>
                    <div className="flex-1 text-left">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium text-white">{conv.designer.name}</h4>
                        <span className="text-xs text-slate-500">{conv.timestamp}</span>
                      </div>
                      <p className="text-sm text-slate-400 truncate">{conv.lastMessage}</p>
                    </div>
                    {conv.unread > 0 && (
                      <Badge className="bg-[#D4AF37] text-black text-xs">{conv.unread}</Badge>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Chat Area */}
            <div className="lg:col-span-2 flex flex-col">
              {activeChat ? (
                <>
                  {/* Chat Header */}
                  <div className="p-4 border-b border-[#D4AF37]/10 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={activeChat.designer.avatar} />
                        <AvatarFallback>{activeChat.designer.name[0]}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h4 className="font-medium text-white">{activeChat.designer.name}</h4>
                        <p className="text-xs text-slate-400">
                          {activeChat.designer.isOnline ? 'Online' : 'Offline'} • {activeChat.designer.specialty}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="icon" className="text-slate-400 hover:text-[#D4AF37]">
                        <PhoneCall className="w-5 h-5" />
                      </Button>
                      <Button variant="ghost" size="icon" className="text-slate-400 hover:text-[#D4AF37]">
                        <VideoIcon className="w-5 h-5" />
                      </Button>
                      <Button variant="ghost" size="icon" className="text-slate-400 hover:text-[#D4AF37]">
                        <MoreVertical className="w-5 h-5" />
                      </Button>
                    </div>
                  </div>

                  {/* Messages */}
                  <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {/* Security Notice */}
                    <div className="flex items-center justify-center gap-2 py-2">
                      <Shield className="w-4 h-4 text-green-500" />
                      <span className="text-xs text-slate-500">
                        Messages are end-to-end encrypted and recorded for security
                      </span>
                    </div>

                    {activeChat.messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex ${message.sender === 'customer' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-[70%] ${
                            message.sender === 'customer'
                              ? 'chat-bubble-customer'
                              : 'chat-bubble-designer'
                          } p-4`}
                        >
                          {message.attachments && (
                            <div className="mb-3">
                              <img
                                src={message.attachments[0]}
                                alt="Attachment"
                                className="rounded-lg max-w-full"
                              />
                            </div>
                          )}
                          <p className="text-white">{message.text}</p>
                          <div className="flex items-center justify-end gap-1 mt-2">
                            <span className="text-xs text-slate-500">{message.timestamp}</span>
                            {message.sender === 'customer' && (
                              <CheckCheck
                                className={`w-4 h-4 ${
                                  message.status === 'read' ? 'text-[#00FFFF]' : 'text-slate-500'
                                }`}
                              />
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                    <div ref={messagesEndRef} />
                  </div>

                  {/* Input Area */}
                  <div className="p-4 border-t border-[#D4AF37]/10">
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="icon" className="text-slate-400 hover:text-[#D4AF37]">
                        <Paperclip className="w-5 h-5" />
                      </Button>
                      <Input
                        placeholder="Type your message..."
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        onKeyPress={handleKeyPress}
                        className="flex-1 bg-[#0F172A] border-[#D4AF37]/30 text-white placeholder:text-slate-500 focus:border-[#D4AF37]"
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setIsRecording(!isRecording)}
                        className={`${isRecording ? 'text-red-500' : 'text-slate-400 hover:text-[#D4AF37]'}`}
                      >
                        <Mic className="w-5 h-5" />
                      </Button>
                      <Button
                        onClick={handleSendMessage}
                        className="bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-black"
                      >
                        <Send className="w-5 h-5" />
                      </Button>
                    </div>
                  </div>
                </>
              ) : (
                <div className="flex-1 flex items-center justify-center">
                  <div className="text-center">
                    <MessageSquare className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                    <h4 className="text-xl font-semibold text-white mb-2">Select a Conversation</h4>
                    <p className="text-slate-400">Choose a designer to start messaging</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Features */}
        <div className="mt-8 grid sm:grid-cols-3 gap-6">
          {[
            { icon: Video, title: 'Video Calls', desc: 'HD video consultations' },
            { icon: Phone, title: 'Voice Calls', desc: 'Crystal clear audio' },
            { icon: Lock, title: 'Encrypted', desc: 'End-to-end security' },
          ].map((feature) => (
            <div key={feature.title} className="flex items-center gap-4 p-4 rounded-xl glass-card">
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[#D4AF37]/20 to-[#00FFFF]/20 flex items-center justify-center">
                <feature.icon className="w-6 h-6 text-[#D4AF37]" />
              </div>
              <div>
                <p className="font-medium text-white">{feature.title}</p>
                <p className="text-sm text-slate-400">{feature.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
