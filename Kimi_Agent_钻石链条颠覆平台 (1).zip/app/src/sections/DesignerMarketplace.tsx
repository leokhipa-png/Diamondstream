import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Search, 
  MapPin, 
  Star, 
  Award, 
  Verified, 
  Heart,
  Eye,
  MessageSquare,
  Filter,
  ChevronDown,
  Gem,
  TrendingUp
} from 'lucide-react';

interface Designer {
  id: string;
  name: string;
  avatar: string;
  location: string;
  specialty: string;
  rating: number;
  reviews: number;
  completedProjects: number;
  isVerified: boolean;
  isPremium: boolean;
  portfolio: string[];
  bio: string;
  startingPrice: string;
  tags: string[];
}

interface DesignerMarketplaceProps {
  onDesignerClick: (designerId: string) => void;
}

export default function DesignerMarketplace({ onDesignerClick }: DesignerMarketplaceProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('all');
  const [showFilters, setShowFilters] = useState(false);

  const designers: Designer[] = [
    {
      id: '1',
      name: 'Elena Rodriguez',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      location: 'New York, USA',
      specialty: 'Engagement Rings',
      rating: 4.9,
      reviews: 127,
      completedProjects: 342,
      isVerified: true,
      isPremium: true,
      portfolio: [
        'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=300&h=300&fit=crop',
        'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=300&h=300&fit=crop',
        'https://images.unsplash.com/photo-1603561591411-07134e71a2a9?w=300&h=300&fit=crop',
      ],
      bio: 'Award-winning jewelry designer specializing in bespoke engagement rings with over 15 years of experience.',
      startingPrice: '$3,500',
      tags: ['Vintage', 'Halo', 'Solitaire', 'Custom'],
    },
    {
      id: '2',
      name: 'Marcus Chen',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
      location: 'Hong Kong',
      specialty: 'Contemporary Designs',
      rating: 4.8,
      reviews: 89,
      completedProjects: 256,
      isVerified: true,
      isPremium: true,
      portfolio: [
        'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=300&h=300&fit=crop',
        'https://images.unsplash.com/photo-1602751584552-8ba420552259?w=300&h=300&fit=crop',
        'https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?w=300&h=300&fit=crop',
      ],
      bio: 'Modern minimalist designs that blend Eastern aesthetics with Western craftsmanship.',
      startingPrice: '$2,800',
      tags: ['Modern', 'Minimalist', 'Geometric', 'Art Deco'],
    },
    {
      id: '3',
      name: 'Sofia Andersson',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
      location: 'Stockholm, Sweden',
      specialty: 'Vintage & Antique',
      rating: 5.0,
      reviews: 64,
      completedProjects: 178,
      isVerified: true,
      isPremium: false,
      portfolio: [
        'https://images.unsplash.com/photo-1598560917505-59a3ad559071?w=300&h=300&fit=crop',
        'https://images.unsplash.com/photo-1608042314453-ae338d80c427?w=300&h=300&fit=crop',
        'https://images.unsplash.com/photo-1611652022419-a9419f74343d?w=300&h=300&fit=crop',
      ],
      bio: 'Passionate about reviving vintage jewelry styles with a modern sustainable approach.',
      startingPrice: '$4,200',
      tags: ['Vintage', 'Edwardian', 'Victorian', 'Filigree'],
    },
    {
      id: '4',
      name: 'James Wellington',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop',
      location: 'London, UK',
      specialty: 'High Jewelry',
      rating: 4.9,
      reviews: 156,
      completedProjects: 423,
      isVerified: true,
      isPremium: true,
      portfolio: [
        'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=300&h=300&fit=crop',
        'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=300&h=300&fit=crop',
        'https://images.unsplash.com/photo-1602173574767-37ac01994b2a?w=300&h=300&fit=crop',
      ],
      bio: 'Former head designer at a prestigious Mayfair atelier, now creating exclusive pieces for discerning clients.',
      startingPrice: '$10,000',
      tags: ['High Jewelry', 'Couture', 'Exclusive', 'Bespoke'],
    },
    {
      id: '5',
      name: 'Aisha Patel',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop',
      location: 'Mumbai, India',
      specialty: 'Traditional Indian',
      rating: 4.7,
      reviews: 203,
      completedProjects: 567,
      isVerified: true,
      isPremium: false,
      portfolio: [
        'https://images.unsplash.com/photo-1601121141461-9d6647bca1ed?w=300&h=300&fit=crop',
        'https://images.unsplash.com/photo-1610694955371-d4a3e0ce4b52?w=300&h=300&fit=crop',
        'https://images.unsplash.com/photo-1600721391689-2564bb8055de?w=300&h=300&fit=crop',
      ],
      bio: 'Fourth-generation jewelry designer bringing centuries-old Indian craftsmanship to the modern world.',
      startingPrice: '$1,800',
      tags: ['Traditional', 'Kundan', 'Polki', 'Bridal'],
    },
    {
      id: '6',
      name: 'Lucas Moreau',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
      location: 'Paris, France',
      specialty: 'Avant-Garde',
      rating: 4.8,
      reviews: 45,
      completedProjects: 89,
      isVerified: true,
      isPremium: true,
      portfolio: [
        'https://images.unsplash.com/photo-1617038220319-276d3cfab638?w=300&h=300&fit=crop',
        'https://images.unsplash.com/photo-1601821765780-754fa92237ab?w=300&h=300&fit=crop',
        'https://images.unsplash.com/photo-1599459183200-59c3a4655ee3?w=300&h=300&fit=crop',
      ],
      bio: 'Pushing the boundaries of jewelry design with unconventional materials and bold concepts.',
      startingPrice: '$5,500',
      tags: ['Avant-Garde', 'Sculptural', 'Unique', 'Artistic'],
    },
  ];

  const specialties = ['all', 'Engagement Rings', 'Contemporary Designs', 'Vintage & Antique', 'High Jewelry', 'Traditional Indian', 'Avant-Garde'];

  const filteredDesigners = designers.filter(designer => {
    const matchesSearch = designer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         designer.specialty.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         designer.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesSpecialty = selectedSpecialty === 'all' || designer.specialty === selectedSpecialty;
    return matchesSearch && matchesSpecialty;
  });

  return (
    <section id="designers" className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-0 w-[400px] h-[400px] bg-[#D4AF37]/5 rounded-full blur-[100px]" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-[#D4AF37]/30 mb-6">
            <Gem className="w-4 h-4 text-[#D4AF37]" />
            <span className="text-sm text-slate-300">Designer Marketplace</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Meet Our <span className="text-gradient-gold">Master Craftsmen</span>
          </h2>
          <p className="text-lg text-slate-400 max-w-2xl mx-auto">
            Connect with verified jewelry designers from around the world. Browse portfolios, 
            read reviews, and find the perfect creator for your vision.
          </p>
        </div>

        {/* Search & Filters */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <Input
                placeholder="Search designers, specialties, or styles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 bg-[#0F172A] border-[#D4AF37]/30 text-white placeholder:text-slate-500 focus:border-[#D4AF37]"
              />
            </div>
            <Button
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
              className="border-[#D4AF37]/30 text-[#D4AF37]"
            >
              <Filter className="w-4 h-4 mr-2" />
              Filters
              <ChevronDown className={`w-4 h-4 ml-2 transition-transform ${showFilters ? 'rotate-180' : ''}`} />
            </Button>
          </div>

          {showFilters && (
            <div className="glass-card rounded-xl p-4 animate-fadeInUp">
              <p className="text-sm text-slate-400 mb-3">Filter by Specialty</p>
              <div className="flex flex-wrap gap-2">
                {specialties.map((specialty) => (
                  <button
                    key={specialty}
                    onClick={() => setSelectedSpecialty(specialty)}
                    className={`px-4 py-2 rounded-full text-sm capitalize transition-all duration-300 ${
                      selectedSpecialty === specialty
                        ? 'bg-[#D4AF37] text-black font-medium'
                        : 'bg-[#0F172A] text-slate-400 border border-[#D4AF37]/20 hover:border-[#D4AF37]/40'
                    }`}
                  >
                    {specialty}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Designers Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDesigners.map((designer, index) => (
            <div
              key={designer.id}
              onClick={() => onDesignerClick(designer.id)}
              className="glass-card rounded-xl overflow-hidden group cursor-pointer hover:border-[#D4AF37]/40 transition-all duration-300"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Portfolio Preview */}
              <div className="relative h-48 overflow-hidden">
                <div className="grid grid-cols-3 h-full gap-1">
                  {designer.portfolio.map((img, i) => (
                    <img
                      key={i}
                      src={img}
                      alt={`${designer.name} portfolio ${i + 1}`}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      style={{ transitionDelay: `${i * 50}ms` }}
                    />
                  ))}
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-[#0F172A] via-transparent to-transparent" />
                
                {/* Badges */}
                <div className="absolute top-3 left-3 flex gap-2">
                  {designer.isPremium && (
                    <Badge className="bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-black">
                      <Award className="w-3 h-3 mr-1" />
                      Premium
                    </Badge>
                  )}
                  {designer.isVerified && (
                    <Badge className="bg-green-500/80 text-white">
                      <Verified className="w-3 h-3 mr-1" />
                      Verified
                    </Badge>
                  )}
                </div>

                {/* Starting Price */}
                <div className="absolute bottom-3 right-3">
                  <span className="px-3 py-1 rounded-full glass text-sm text-white">
                    From {designer.startingPrice}
                  </span>
                </div>
              </div>

              {/* Designer Info */}
              <div className="p-5">
                <div className="flex items-start gap-4 mb-4">
                  <img
                    src={designer.avatar}
                    alt={designer.name}
                    className="w-14 h-14 rounded-full object-cover border-2 border-[#D4AF37]/30"
                  />
                  <div className="flex-1">
                    <h3 className="font-semibold text-white group-hover:text-[#D4AF37] transition-colors">
                      {designer.name}
                    </h3>
                    <p className="text-sm text-slate-400">{designer.specialty}</p>
                    <div className="flex items-center gap-1 text-sm text-slate-500 mt-1">
                      <MapPin className="w-3 h-3" />
                      {designer.location}
                    </div>
                  </div>
                </div>

                {/* Stats */}
                <div className="flex items-center gap-4 mb-4 text-sm">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-[#D4AF37] fill-[#D4AF37]" />
                    <span className="text-white font-medium">{designer.rating}</span>
                    <span className="text-slate-500">({designer.reviews})</span>
                  </div>
                  <div className="flex items-center gap-1 text-slate-400">
                    <TrendingUp className="w-4 h-4" />
                    <span>{designer.completedProjects} projects</span>
                  </div>
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {designer.tags.slice(0, 3).map((tag) => (
                    <span
                      key={tag}
                      className="px-2 py-1 rounded-md bg-[#0F172A] text-xs text-slate-400"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Actions */}
                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 border-[#D4AF37]/30 text-[#D4AF37] hover:bg-[#D4AF37]/10"
                    onClick={(e) => {
                      e.stopPropagation();
                    }}
                  >
                    <Heart className="w-4 h-4 mr-2" />
                    Save
                  </Button>
                  <Button
                    size="sm"
                    className="flex-1 bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-black font-medium"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDesignerClick(designer.id);
                    }}
                  >
                    <MessageSquare className="w-4 h-4 mr-2" />
                    Connect
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Load More */}
        <div className="text-center mt-12">
          <Button
            variant="outline"
            className="border-[#D4AF37]/30 text-[#D4AF37] hover:bg-[#D4AF37]/10"
          >
            <Eye className="w-4 h-4 mr-2" />
            View All Designers
          </Button>
        </div>
      </div>
    </section>
  );
}
