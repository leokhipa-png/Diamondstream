import { useState, useEffect } from 'react';
import { Diamond, Menu, X, User, LogOut, ShoppingBag, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { UserRole, ViewState } from '@/App';

interface NavigationProps {
  isLoggedIn: boolean;
  userRole: UserRole;
  onOpenAuth: (mode: 'login' | 'signup') => void;
  onLogout: () => void;
  onNavigateHome: () => void;
  onNavigateOrders: () => void;
  currentView: ViewState;
}

export default function Navigation({ 
  isLoggedIn, 
  userRole, 
  onOpenAuth, 
  onLogout,
  onNavigateHome,
  onNavigateOrders,
  currentView
}: NavigationProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    if (currentView !== 'home') {
      onNavigateHome();
      setTimeout(() => {
        const element = document.getElementById(id);
        element?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      const element = document.getElementById(id);
      element?.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  const navLinks = [
    { label: 'AI Studio', id: 'ai-studio' },
    { label: 'Designers', id: 'designers' },
    { label: 'How It Works', id: 'how-it-works' },
    { label: 'Verification', id: 'verification' },
    { label: 'Pricing', id: 'pricing' },
  ];

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled 
          ? 'glass py-3' 
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <button 
            onClick={onNavigateHome}
            className="flex items-center gap-2 group"
          >
            <Diamond className="w-8 h-8 text-[#D4AF37] group-hover:rotate-45 transition-transform duration-500" />
            <span className="text-xl font-bold text-gradient-gold font-['Playfair_Display']">
              DIAMOND.ai
            </span>
          </button>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {currentView === 'home' && navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => scrollToSection(link.id)}
                className="text-sm text-slate-300 hover:text-[#D4AF37] transition-colors duration-300 relative group"
              >
                {link.label}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#D4AF37] group-hover:w-full transition-all duration-300" />
              </button>
            ))}
          </div>

          {/* Right Side Actions */}
          <div className="hidden md:flex items-center gap-4">
            {isLoggedIn ? (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onNavigateOrders}
                  className="text-slate-300 hover:text-[#D4AF37] hover:bg-[#D4AF37]/10"
                >
                  <ShoppingBag className="w-4 h-4 mr-2" />
                  Orders
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-slate-300 hover:text-[#D4AF37] hover:bg-[#D4AF37]/10"
                >
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Messages
                </Button>
                <div className="flex items-center gap-2 px-3 py-1.5 glass rounded-full">
                  <User className="w-4 h-4 text-[#D4AF37]" />
                  <span className="text-sm text-slate-300 capitalize">{userRole}</span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onLogout}
                  className="text-slate-400 hover:text-red-400 hover:bg-red-400/10"
                >
                  <LogOut className="w-4 h-4" />
                </Button>
              </>
            ) : (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onOpenAuth('login')}
                  className="text-slate-300 hover:text-[#D4AF37] hover:bg-[#D4AF37]/10"
                >
                  Sign In
                </Button>
                <Button
                  size="sm"
                  onClick={() => onOpenAuth('signup')}
                  className="bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-black font-medium hover:shadow-lg hover:shadow-[#D4AF37]/30 transition-all duration-300"
                >
                  Get Started
                </Button>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-slate-300"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden mt-4 py-4 border-t border-[#D4AF37]/20">
            <div className="flex flex-col gap-4">
              {currentView === 'home' && navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => scrollToSection(link.id)}
                  className="text-left text-slate-300 hover:text-[#D4AF37] transition-colors"
                >
                  {link.label}
                </button>
              ))}
              {!isLoggedIn ? (
                <div className="flex gap-3 pt-4 border-t border-[#D4AF37]/20">
                  <Button
                    variant="outline"
                    className="flex-1 border-[#D4AF37]/50 text-[#D4AF37]"
                    onClick={() => {
                      onOpenAuth('login');
                      setIsMobileMenuOpen(false);
                    }}
                  >
                    Sign In
                  </Button>
                  <Button
                    className="flex-1 bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-black"
                    onClick={() => {
                      onOpenAuth('signup');
                      setIsMobileMenuOpen(false);
                    }}
                  >
                    Get Started
                  </Button>
                </div>
              ) : (
                <div className="pt-4 border-t border-[#D4AF37]/20">
                  <div className="flex items-center gap-2 mb-4">
                    <User className="w-5 h-5 text-[#D4AF37]" />
                    <span className="text-slate-300 capitalize">{userRole} Account</span>
                  </div>
                  <Button
                    variant="outline"
                    className="w-full border-red-400/50 text-red-400"
                    onClick={() => {
                      onLogout();
                      setIsMobileMenuOpen(false);
                    }}
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Sign Out
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
