import { useState } from 'react';
import { X, Diamond, User, Store, Factory, Eye, EyeOff, Upload, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import type { UserRole } from '@/App';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'login' | 'signup';
  onLogin: (role: UserRole) => void;
}

type SignupStep = 'role' | 'details' | 'verification' | 'success';

export default function AuthModal({ isOpen, onClose, mode, onLogin }: AuthModalProps) {
  const [activeMode, setActiveMode] = useState<'login' | 'signup'>(mode);
  const [signupStep, setSignupStep] = useState<SignupStep>('role');
  const [selectedRole, setSelectedRole] = useState<UserRole>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [companyName, setCompanyName] = useState('');

  if (!isOpen) return null;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsLoading(false);
    onLogin('customer');
  };

  const handleRoleSelect = (role: UserRole) => {
    setSelectedRole(role);
    setSignupStep('details');
  };

  const handleDetailsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsLoading(false);
    if (selectedRole && selectedRole !== 'customer') {
      setSignupStep('verification');
    } else {
      setSignupStep('success');
    }
  };

  const handleVerificationSubmit = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsLoading(false);
    setSignupStep('success');
  };

  const handleSuccess = () => {
    onLogin(selectedRole);
    // Reset state
    setSignupStep('role');
    setSelectedRole(null);
    setEmail('');
    setPassword('');
    setFullName('');
    setCompanyName('');
  };

  const roles = [
    { id: 'customer', label: 'Customer', icon: User, description: 'Design & purchase custom jewelry' },
    { id: 'designer', label: 'Jewelry Designer', icon: Diamond, description: 'Create & sell your designs' },
    { id: 'dealer', label: 'Diamond Dealer', icon: Store, description: 'Supply certified diamonds' },
    { id: 'manufacturer', label: 'Manufacturer', icon: Factory, description: 'Craft jewelry pieces' },
  ];

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-lg glass-card rounded-2xl overflow-hidden max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-[#D4AF37]/20">
          <div className="flex items-center gap-2">
            <Diamond className="w-6 h-6 text-[#D4AF37]" />
            <span className="text-lg font-bold text-gradient-gold font-['Playfair_Display']">
              DIAMOND.ai
            </span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {activeMode === 'login' ? (
            <form onSubmit={handleLogin} className="space-y-6">
              <div className="text-center">
                <h2 className="text-2xl font-bold text-white mb-2">Welcome Back</h2>
                <p className="text-slate-400">Sign in to continue your journey</p>
              </div>

              <div className="space-y-4">
                <div>
                  <Label className="text-slate-300">Email</Label>
                  <Input
                    type="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="bg-[#0F172A] border-[#D4AF37]/30 text-white placeholder:text-slate-500 focus:border-[#D4AF37]"
                    required
                  />
                </div>
                <div>
                  <Label className="text-slate-300">Password</Label>
                  <div className="relative">
                    <Input
                      type={showPassword ? 'text' : 'password'}
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="bg-[#0F172A] border-[#D4AF37]/30 text-white placeholder:text-slate-500 focus:border-[#D4AF37] pr-10"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>

              <Button
                type="submit"
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-black font-medium hover:shadow-lg hover:shadow-[#D4AF37]/30"
              >
                {isLoading ? 'Signing in...' : 'Sign In'}
              </Button>

              <p className="text-center text-sm text-slate-400">
                Don&apos;t have an account?{' '}
                <button
                  type="button"
                  onClick={() => setActiveMode('signup')}
                  className="text-[#D4AF37] hover:underline"
                >
                  Sign up
                </button>
              </p>
            </form>
          ) : (
            <div>
              {signupStep === 'role' && (
                <div className="space-y-6">
                  <div className="text-center">
                    <h2 className="text-2xl font-bold text-white mb-2">Choose Your Role</h2>
                    <p className="text-slate-400">Select how you want to use DIAMOND.ai</p>
                  </div>

                  <div className="grid grid-cols-1 gap-3">
                    {roles.map((role) => (
                      <button
                        key={role.id}
                        onClick={() => handleRoleSelect(role.id as UserRole)}
                        className="flex items-center gap-4 p-4 rounded-xl border border-[#D4AF37]/20 hover:border-[#D4AF37]/50 hover:bg-[#D4AF37]/5 transition-all duration-300 text-left"
                      >
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#D4AF37]/20 to-[#00FFFF]/20 flex items-center justify-center">
                          <role.icon className="w-6 h-6 text-[#D4AF37]" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-white">{role.label}</h3>
                          <p className="text-sm text-slate-400">{role.description}</p>
                        </div>
                      </button>
                    ))}
                  </div>

                  <p className="text-center text-sm text-slate-400">
                    Already have an account?{' '}
                    <button
                      onClick={() => setActiveMode('login')}
                      className="text-[#D4AF37] hover:underline"
                    >
                      Sign in
                    </button>
                  </p>
                </div>
              )}

              {signupStep === 'details' && (
                <form onSubmit={handleDetailsSubmit} className="space-y-6">
                  <div className="text-center">
                    <h2 className="text-2xl font-bold text-white mb-2">Create Your Account</h2>
                    <p className="text-slate-400">
                      Join as <span className="text-[#D4AF37] capitalize">{selectedRole}</span>
                    </p>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <Label className="text-slate-300">Full Name</Label>
                      <Input
                        type="text"
                        placeholder="John Doe"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        className="bg-[#0F172A] border-[#D4AF37]/30 text-white placeholder:text-slate-500 focus:border-[#D4AF37]"
                        required
                      />
                    </div>
                    {selectedRole !== 'customer' && (
                      <div>
                        <Label className="text-slate-300">Company Name</Label>
                        <Input
                          type="text"
                          placeholder="Your Company Ltd."
                          value={companyName}
                          onChange={(e) => setCompanyName(e.target.value)}
                          className="bg-[#0F172A] border-[#D4AF37]/30 text-white placeholder:text-slate-500 focus:border-[#D4AF37]"
                          required
                        />
                      </div>
                    )}
                    <div>
                      <Label className="text-slate-300">Email</Label>
                      <Input
                        type="email"
                        placeholder="you@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="bg-[#0F172A] border-[#D4AF37]/30 text-white placeholder:text-slate-500 focus:border-[#D4AF37]"
                        required
                      />
                    </div>
                    <div>
                      <Label className="text-slate-300">Password</Label>
                      <div className="relative">
                        <Input
                          type={showPassword ? 'text' : 'password'}
                          placeholder="••••••••"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="bg-[#0F172A] border-[#D4AF37]/30 text-white placeholder:text-slate-500 focus:border-[#D4AF37] pr-10"
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400"
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setSignupStep('role')}
                      className="flex-1 border-[#D4AF37]/30 text-slate-300"
                    >
                      Back
                    </Button>
                    <Button
                      type="submit"
                      disabled={isLoading}
                      className="flex-1 bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-black font-medium"
                    >
                      {isLoading ? 'Please wait...' : 'Continue'}
                    </Button>
                  </div>
                </form>
              )}

              {signupStep === 'verification' && (
                <div className="space-y-6">
                  <div className="text-center">
                    <h2 className="text-2xl font-bold text-white mb-2">Verify Your Identity</h2>
                    <p className="text-slate-400">
                      Upload required documents for <span className="text-[#D4AF37] capitalize">{selectedRole}</span> verification
                    </p>
                  </div>

                  <div className="space-y-4">
                    <div className="p-4 rounded-xl border border-dashed border-[#D4AF37]/30 hover:border-[#D4AF37]/50 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-[#D4AF37]/10 flex items-center justify-center">
                          <Upload className="w-5 h-5 text-[#D4AF37]" />
                        </div>
                        <div className="flex-1">
                          <p className="text-white font-medium">Business Certificate</p>
                          <p className="text-sm text-slate-400">PDF, JPG, or PNG up to 10MB</p>
                        </div>
                        <Button variant="outline" size="sm" className="border-[#D4AF37]/30 text-[#D4AF37]">
                          Upload
                        </Button>
                      </div>
                    </div>

                    <div className="p-4 rounded-xl border border-dashed border-[#D4AF37]/30 hover:border-[#D4AF37]/50 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-[#D4AF37]/10 flex items-center justify-center">
                          <Upload className="w-5 h-5 text-[#D4AF37]" />
                        </div>
                        <div className="flex-1">
                          <p className="text-white font-medium">Government ID / Passport</p>
                          <p className="text-sm text-slate-400">Clear photo or scan</p>
                        </div>
                        <Button variant="outline" size="sm" className="border-[#D4AF37]/30 text-[#D4AF37]">
                          Upload
                        </Button>
                      </div>
                    </div>

                    {selectedRole === 'dealer' && (
                      <div className="p-4 rounded-xl border border-dashed border-[#D4AF37]/30 hover:border-[#D4AF37]/50 transition-colors">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-[#D4AF37]/10 flex items-center justify-center">
                            <Upload className="w-5 h-5 text-[#D4AF37]" />
                          </div>
                          <div className="flex-1">
                            <p className="text-white font-medium">Diamond Certification</p>
                            <p className="text-sm text-slate-400">GIA, IGI, or HRD certificates</p>
                          </div>
                          <Button variant="outline" size="sm" className="border-[#D4AF37]/30 text-[#D4AF37]">
                            Upload
                          </Button>
                        </div>
                      </div>
                    )}

                    <div className="p-4 rounded-xl border border-dashed border-[#D4AF37]/30 hover:border-[#D4AF37]/50 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-[#D4AF37]/10 flex items-center justify-center">
                          <Upload className="w-5 h-5 text-[#D4AF37]" />
                        </div>
                        <div className="flex-1">
                          <p className="text-white font-medium">Proof of Address</p>
                          <p className="text-sm text-slate-400">Utility bill or bank statement</p>
                        </div>
                        <Button variant="outline" size="sm" className="border-[#D4AF37]/30 text-[#D4AF37]">
                          Upload
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setSignupStep('details')}
                      className="flex-1 border-[#D4AF37]/30 text-slate-300"
                    >
                      Back
                    </Button>
                    <Button
                      onClick={handleVerificationSubmit}
                      disabled={isLoading}
                      className="flex-1 bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-black font-medium"
                    >
                      {isLoading ? 'Verifying...' : 'Submit for Verification'}
                    </Button>
                  </div>
                </div>
              )}

              {signupStep === 'success' && (
                <div className="text-center space-y-6 py-8">
                  <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center">
                    <CheckCircle className="w-10 h-10 text-white" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-white mb-2">Welcome to DIAMOND.ai!</h2>
                    <p className="text-slate-400">
                      Your account has been created successfully. {selectedRole !== 'customer' && 'Your documents are under review.'}
                    </p>
                  </div>
                  <Button
                    onClick={handleSuccess}
                    className="w-full bg-gradient-to-r from-[#D4AF37] to-[#B8941F] text-black font-medium"
                  >
                    Get Started
                  </Button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
